# 个人持仓新闻解读与风险提醒报告

生成时间：2026-05-17 00:44:48

> 本报告由多智能体流程生成；如启用 LLM 精修，会在规则分析结果基础上进行语言组织。

## 持仓快照

- 账户基准货币：CNY
- 数据日期：2026-05-17
- 示例持仓数量：1
- 示例总市值：137,000.00

## 行情快照

- 600519.SH：2025-08-13 至 2026-05-15，收盘价从 1420.05 变为 1332.95，变化 -6.13%。

## 技术图表

### 600519.SH
K 线叠加 MA5 / MA10 / MA20：
![600519.SH K线均线图](outputs/charts/600519_SH_kline_ma.png)

MACD：
![600519.SH MACD图](outputs/charts/600519_SH_macd.png)

成交额（若数据源未直接提供成交额，则按均价×成交量估算）：
![600519.SH 成交额图](outputs/charts/600519_SH_amount.png)

## 新闻抓取概览

- 本次纳入新闻数量：59 条
- 抓取来源类型：google_news_zh_rss 59 条
- 关联标的分布：600519.SH 41 条
- 情绪/风险标签分布：neutral 22 条，positive 18 条，risk 19 条

## 最近财报与公告概览

- 本次纳入财报/财务相关公告数量：8 条
- 最新一条：2026-04-29 贵州茅台:贵州茅台关于召开2025年度及2026年第一季度业绩说明会的公告

## 多智能体分析结果

## 新闻解读智能体

样本覆盖：41 条直接相关资讯；标签分布为 {'risk': 18, 'neutral': 13, 'positive': 10}。

核心主题归纳：
- 压力主题：18 条资讯被识别为风险类，集中在业绩下滑、资金净卖出、管理层/治理事件、白酒需求与价格体系变化。
- 支撑主题：10 条资讯被识别为正面类，主要涉及分红、回购、提价、季度增长或渠道改善。
- 可量化线索：净卖出3.80亿元；净利降4.53%；分红350亿元；提价 - 新浪财经 最高涨价200元；净卖出6.52亿元；净卖出11.23亿元；净卖出11.78亿元；净利下滑：2025年净利润823亿元同比下降4.53%。

代表性证据链：
- [risk] 股票行情快报：贵州茅台（600519）5月14日主力资金净卖出3.80亿元_主力研究 - 证券之星（证券之星）：股票行情快报：贵州茅台（600519）5月14日主力资金净卖出3.80亿元_主力研究 证券之星
- [risk] 上市以来首次年度业绩下滑！贵州茅台去年净利降4.53%，拟分红350亿元 - thepaper.cn（thepaper.cn）：上市以来首次年度业绩下滑！贵州茅台去年净利降4.53%，拟分红350亿元 thepaper.cn
- [neutral] 贵州茅台(600519.SH)今年不设经营目标 王莉：顺应市场规律而不只是决定於供给侧 - AASTOCKS.com（AASTOCKS.com）：贵州茅台(600519.SH)今年不设经营目标 王莉：顺应市场规律而不只是决定於供给侧 AASTOCKS.com
- [neutral] 贵州茅台宣布：聘任余思明为财务总监并代行董秘职责，董事长陈华不再代行董秘职责 - 东方财富（东方财富）：贵州茅台宣布：聘任余思明为财务总监并代行董秘职责，董事长陈华不再代行董秘职责 东方财富
- [positive] 最高涨价200元！贵州茅台宣布公斤茅台等四款产品提价 - 新浪财经（新浪财经）：最高涨价200元！贵州茅台宣布公斤茅台等四款产品提价 新浪财经
- [neutral] 贵州茅台：这些“会所”，都是假的 - 海报新闻（海报新闻）：贵州茅台：这些“会所”，都是假的 海报新闻
- [neutral] 贵州茅台：未接到换帅消息 袁董到退休年纪已属“超期服役” - 每日经济新闻（每日经济新闻）：贵州茅台：未接到换帅消息 袁董到退休年纪已属“超期服役” 每日经济新闻
- [risk] 公募对贵州茅台的调仓出现分歧，刘格菘、莫海波逆势加仓| 基金放大镜-腾讯新闻 - qq.com（qq.com）：公募对贵州茅台的调仓出现分歧，刘格菘、莫海波逆势加仓| 基金放大镜-腾讯新闻 qq.com
- [neutral] 贵州茅台已经算不错了中国中免，上海机场，惨多了 - 新浪网（新浪网）：贵州茅台已经算不错了中国中免，上海机场，惨多了 新浪网
- [risk] 股票行情快报：贵州茅台（600519）5月15日主力资金净卖出6.52亿元_主力研究 - 证券之星（证券之星）：股票行情快报：贵州茅台（600519）5月15日主力资金净卖出6.52亿元_主力研究 证券之星
- 其余 31 条直接相关资讯见新闻明细。

## 财报公告智能体

公告样本：8 条，其中年度报告 3 条、季度报告 2 条、分红/利润分配 2 条、业绩说明 1 条。

公告解读框架：
- 年报线索：最新年报相关公告为 2026-04-17《贵州茅台:贵州茅台2025年年度报告(英文版)》。
- 季报线索：最新季报相关公告为 2026-04-25《贵州茅台:贵州茅台2026年第一季度报告》。
- 股东回报线索：存在利润分配/分红安排公告，说明现金回报是当前市场关注点之一。
- 沟通线索：业绩说明会公告意味着管理层将回应经营质量、增长目标、渠道库存和价格体系等问题。
- 新闻中提取到的财务数字：净卖出3.80亿元；净利降4.53%；分红350亿元；提价 - 新浪财经 最高涨价200元；净卖出6.52亿元；净卖出11.23亿元；净卖出11.78亿元；净利下滑：2025年净利润823亿元同比下降4.53%；净利润823亿元同比下降4.53%；营收1688.38亿元（同比-1.21%。

分析师式追问：
- 年度收入和净利润变化是否来自销量、价格、产品结构、渠道投放或费用率变化。
- 高分红和回购是否足以抵消增长放缓带来的估值压力。
- 季报改善是否具有持续性，还是基数、发货节奏或费用确认带来的阶段性变化。

## 技术观察智能体

### 600519.SH
样本区间：2025-08-13 至 2026-05-15。本模块计算趋势、动量、波动、量能、估值五类指标，共 31 项。

| 指标 | 数值 | 含义 |
| --- | ---: | --- |
| 收盘价 | 1332.95 | 最新价格观察基准 |
| 区间收益率 | -6.13% | 衡量样本期方向 |
| 区间振幅 | 18.61% | 衡量高低点波动空间 |
| 最大回撤 | -14.28% | 衡量样本期下行压力 |
| MA5 | 1347.02 | 短线均线 |
| MA10 | 1364.01 | 短中线均线 |
| MA20 | 1394.79 | 月度均线 |
| MA60 | 1427.80 | 季度均线 |
| EMA12 | 1368.32 | MACD 快线基础 |
| EMA26 | 1393.08 | MACD 慢线基础 |
| MACD DIF | -24.76 | 快慢均线差 |
| MACD DEA | -18.06 | DIF 平滑线 |
| MACD 柱 | -13.40 | 动能变化 |
| RSI6 | 4.62 | 短线强弱 |
| RSI12 | 2.81 | 中短线强弱 |
| RSI24 | 27.65 | 中期强弱 |
| KDJ K | 8.29 | 随机指标 K 值 |
| KDJ D | 9.17 | 随机指标 D 值 |
| KDJ J | 6.54 | 敏感摆动值 |
| BOLL 中轨 | 1394.79 | 20 日均线 |
| BOLL 上轨 | 1473.11 | 压力观察位 |
| BOLL 下轨 | 1316.47 | 支撑观察位 |
| BOLL 带宽 | 11.23% | 波动收敛/扩张 |
| BOLL %B | 10.52 | 价格在布林区间的位置 |
| ATR14 | 21.91 | 平均真实波幅 |
| 20日年化波动率 | 23.09% | 近期波动水平 |
| 成交量/5日均量 | 1.05 | 量能确认 |
| 区间价格分位 | 4.45% | 收盘价在样本高低点中的位置 |
| 换手率 | 0.46% | 交易活跃度 |
| 动态PE | 15.32 | 估值指标 |
| PB | 6.16 | 净资产估值 |

综合解读：
- 趋势：收盘 1332.95，MA5/MA20/MA60 分别为 1347.02/1394.79/1427.80，结构判断为空头或震荡。
- 动量：MACD DIF -24.76、DEA -18.06、柱值 -13.40，判断为动能偏弱；RSI6/12/24 为 4.62/2.81/27.65，对应短线偏冷、中期弱势。
- 摆动：KDJ K/D/J 为 8.29/9.17/6.54，处于摆动区间内；BOLL %B 为 10.52，价格贴近下轨。
- 波动：ATR14 为 21.91，20日年化波动率 23.09%，区间最大回撤 -14.28%，说明短期波动压力需要和新闻/公告同步观察。
- 量能：成交量/5日均量为 1.05，换手率 0.46%，属于量能平稳。若价格方向与量能背离，信号可信度下降。
- 估值：动态PE 15.32，PB 6.16，判断为估值中性偏高；对贵州茅台这类消费龙头，估值需要和利润增速、现金分红、品牌溢价一起解释。
- 技术面结论：若趋势、MACD、RSI、量能同时改善，说明短线修复更有一致性；若估值仍高而业绩新闻偏弱，则技术反弹更容易受基本面预期压制。

## 风险提示智能体

风险分层：
- 持仓暴露：贵州茅台（600519.SH）市值 137,000.00，组合权重 100.00%，相对成本收益 -8.67%。
  推理：单一标的权重较高，新闻、财报或价格波动会直接主导组合净值变化。
  推理：当前价格低于样例成本，若基本面负面线索继续增加，心理止损压力和波动承受能力需要提前评估。
- 市场波动：600519.SH 样本区间收益 -6.13%，最大回撤 -14.28%，振幅 18.61%，动态PE 15.32，PB 6.16。
  推理：价格波动已经具备短期风险暴露特征，需要和新闻事件时间点交叉验证。
- 信息面压力：直接相关新闻 41 条，其中风险类 18 条、正面类 10 条。
  主要风险标题：
  - 股票行情快报：贵州茅台（600519）5月14日主力资金净卖出3.80亿元_主力研究 - 证券之星
  - 上市以来首次年度业绩下滑！贵州茅台去年净利降4.53%，拟分红350亿元 - thepaper.cn
  - 公募对贵州茅台的调仓出现分歧，刘格菘、莫海波逆势加仓| 基金放大镜-腾讯新闻 - qq.com
  - 股票行情快报：贵州茅台（600519）5月15日主力资金净卖出6.52亿元_主力研究 - 证券之星
  - 股票行情快报：贵州茅台（600519）5月12日主力资金净卖出11.23亿元_主力研究 - 证券之星
  - 股票行情快报：贵州茅台（600519）5月13日主力资金净卖出11.78亿元_主力研究 - 证券之星
  可量化风险/支撑线索：净卖出3.80亿元；净利降4.53%；分红350亿元；提价 - 新浪财经 最高涨价200元；净卖出6.52亿元；净卖出11.23亿元；净卖出11.78亿元；净利下滑：2025年净利润823亿元同比下降4.53%；净利润823亿元同比下降4.53%；营收1688.38亿元（同比-1.21%。
- 财报公告压力测试：最近财务公告包含 贵州茅台:贵州茅台关于召开2025年度及2026年第一季度业绩说明会的公告；贵州茅台:贵州茅台2026年第一季度报告；贵州茅台:贵州茅台2025年年度报告(英文版)；贵州茅台:贵州茅台2025年年度报告摘要；贵州茅台:贵州茅台关于2025年年度利润分配方案及2026年中期利润分配安排的公告。
  推理：年度报告、季度报告、利润分配和业绩说明会公告同时出现时，应重点核对收入增速、净利润增速、现金分红、回购安排和管理层回应。

需要继续追踪的触发器：
- 后续公告是否修正经营目标、分红安排、回购进度或管理层职责。
- 白酒终端动销、批价、渠道库存是否和财报中的收入/利润变化相互印证。
- 资金流向新闻是否从单日净卖出演变为连续多日同向变化。

## 综合提醒

- 当前示例持仓集中于 A 股单一白酒龙头，报告重点应放在业绩增速、分红回购、价格体系、渠道库存、管理层/公告事件和资金面变化。
- 新闻与公告需要交叉验证：新闻负责捕捉市场预期变化，公告负责确认公司正式披露口径，行情负责观察预期是否已经反映到价格和成交量中。
- 后续最值得跟踪的是年度报告和季度报告中的收入、净利润、现金分红、回购进展，以及业绩说明会对经营目标和渠道动销的回应。
- 本系统只做信息整理、现象描述和风险提示，不输出任何买入、卖出或持有建议。

免责声明：本系统仅用于课程演示和市场信息解读，不构成投资建议。

## 最近财报与财务相关公告明细

### 1. 贵州茅台:贵州茅台关于召开2025年度及2026年第一季度业绩说明会的公告

- 股票：贵州茅台（600519.SH）
- 日期：2026-04-29
- 来源：东方财富公告
- 栏目：其他
- 链接：https://data.eastmoney.com/notices/detail/600519/AN202604281821673334.html

### 2. 贵州茅台:贵州茅台2026年第一季度报告

- 股票：贵州茅台（600519.SH）
- 日期：2026-04-25
- 来源：东方财富公告
- 栏目：一季度报告全文
- 链接：https://data.eastmoney.com/notices/detail/600519/AN202604241821559413.html

### 3. 贵州茅台:贵州茅台2025年年度报告(英文版)

- 股票：贵州茅台（600519.SH）
- 日期：2026-04-17
- 来源：东方财富公告
- 栏目：年度报告全文(英文)
- 链接：https://data.eastmoney.com/notices/detail/600519/AN202604161821275622.html

### 4. 贵州茅台:贵州茅台2025年年度报告摘要

- 股票：贵州茅台（600519.SH）
- 日期：2026-04-17
- 来源：东方财富公告
- 栏目：年度报告摘要
- 链接：https://data.eastmoney.com/notices/detail/600519/AN202604161821275613.html

### 5. 贵州茅台:贵州茅台关于2025年年度利润分配方案及2026年中期利润分配安排的公告

- 股票：贵州茅台（600519.SH）
- 日期：2026-04-17
- 来源：东方财富公告
- 栏目：分配预案
- 链接：https://data.eastmoney.com/notices/detail/600519/AN202604161821275629.html

### 6. 贵州茅台:贵州茅台2025年年度报告

- 股票：贵州茅台（600519.SH）
- 日期：2026-04-17
- 来源：东方财富公告
- 栏目：年度报告全文
- 链接：https://data.eastmoney.com/notices/detail/600519/AN202604161821275610.html

### 7. 贵州茅台:贵州茅台关于2025年中期利润分配方案暨贯彻落实“提质增效重回报”专项行动方案的公告

- 股票：贵州茅台（600519.SH）
- 日期：2025-11-06
- 来源：东方财富公告
- 栏目：分配预案
- 链接：https://data.eastmoney.com/notices/detail/600519/AN202511051775759374.html

### 8. 贵州茅台:贵州茅台2025年第三季度报告

- 股票：贵州茅台（600519.SH）
- 日期：2025-10-30
- 来源：东方财富公告
- 栏目：三季度报告全文
- 链接：https://data.eastmoney.com/notices/detail/600519/AN202510291771332923.html


## 新闻明细（不少于 50 条）

### 1. 股票行情快报：贵州茅台（600519）5月14日主力资金净卖出3.80亿元_主力研究 - 证券之星

- 来源：证券之星
- 日期：Thu, 14 May 2026 11:53:28 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTE5IWF94VHNwb1hZMkZMWjdxSVpzRHhtQ0pLbEl3Z0RlZGtxV1VvR3UxTmJURlZyM3R0T0Ixa1hPWVdPbXFtV1VnUTZETE44LU5lZWtBQnJhbGxqMWZoWkRyQnlR?oc=5
- 摘要：股票行情快报：贵州茅台（600519）5月14日主力资金净卖出3.80亿元_主力研究 证券之星

### 2. 上市以来首次年度业绩下滑！贵州茅台去年净利降4.53%，拟分红350亿元 - thepaper.cn

- 来源：thepaper.cn
- 日期：Fri, 17 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYEFVX3lxTE80cFpYNHhvZ1NIaFVHOUtoTFJSUE9iZ0FUSGpFUUVqN3dDQ0JsOEhNU1BFeWl4UVpNbmI1S1NpY3B2bnQtNXRFanpUSUs3bWVjWTV3aUg5V2pkOVRRaC1RVA?oc=5
- 摘要：上市以来首次年度业绩下滑！贵州茅台去年净利降4.53%，拟分红350亿元 thepaper.cn

### 3. 贵州茅台(600519.SH)今年不设经营目标 王莉：顺应市场规律而不只是决定於供给侧 - AASTOCKS.com

- 来源：AASTOCKS.com
- 日期：Tue, 12 May 2026 02:17:00 GMT
- 相关标的：600519.SH
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMifEFVX3lxTE9jVDlSWVpyX3VSRE8taWdvUlNPbXRYeTIxSXgyM0ZTamtxenJqcks2SWV3SDdwcG1HVnJrOGI5NXJ2MG1ucVpKdmd4QWZYenB0LUJ4R1FpVVpCSzZOazRUWGU4bS1HQ2tXdDg3NHlSaGU3WlpDRUg1MFluUk4?oc=5
- 摘要：贵州茅台(600519.SH)今年不设经营目标 王莉：顺应市场规律而不只是决定於供给侧 AASTOCKS.com

### 4. 贵州茅台宣布：聘任余思明为财务总监并代行董秘职责，董事长陈华不再代行董秘职责 - 东方财富

- 来源：东方财富
- 日期：Tue, 14 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYEFVX3lxTFBISm5fRVA0VnBnYmJtTldYTVhVWFl3bWI0ZHhOLVc3Y2JPRGszQjZHTGtZQTRkd0UzMkYwUGV3RDFwZ01Vd3pjbDBpOHV2UkRLV1NGWVpwSVZuRF9IMnA2Tg?oc=5
- 摘要：贵州茅台宣布：聘任余思明为财务总监并代行董秘职责，董事长陈华不再代行董秘职责 东方财富

### 5. 最高涨价200元！贵州茅台宣布公斤茅台等四款产品提价 - 新浪财经

- 来源：新浪财经
- 日期：Sat, 16 May 2026 01:29:00 GMT
- 相关标的：600519.SH
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMieEFVX3lxTE54SS1CZDM1QnNXVzhYVUo5YTFVeEJRb3lZSWs4amtCS0Jpd0FXaHhkWWtjTGo1dGQzSzZfVXIwSFRYa2FjOTEwTkxjRmdkeE9VamVENmpCWVZQQ2tWV1NSWnFaNnpTaDQzSDkyNEt2ZjBDWnRoTVlGXw?oc=5
- 摘要：最高涨价200元！贵州茅台宣布公斤茅台等四款产品提价 新浪财经

### 6. 部分茅台酒产品价格上调，最高每瓶涨价200元 - 搜狐网

- 来源：搜狐网
- 日期：Sat, 16 May 2026 01:36:45 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMi5wFBVV95cUxQZm9uYnZENXVodEtaM1dwT3luVEhiUE4wUTVVT0VrOEVWNzRkb1pWWTM1dDI5WnpNZ25ydjVFWnBqLWpfc1hrQVVwT21idFdLS2o0U2F5cUlrZmJiQ0NiOE8xVHdyQ1l1RVNRSmVrT212UXM0WE12X2hhT1ZNSUMxbGhEb1dVVWhsdTlNV2Nlb0tEcERQSHhNaTlfeTZfSDlOVDN2YTZVdWNNZkxYUlFqbHBqcGl6bUJ5c0o1cjBpMTJ4d09MVmd1SVRxQ3V5eUFpcFlWQ2lDVllfczlUd29acXlsYmhvaXM?oc=5
- 摘要：部分茅台酒产品价格上调，最高每瓶涨价200元 搜狐网

### 7. 贵州茅台：这些“会所”，都是假的 - 海报新闻

- 来源：海报新闻
- 日期：Thu, 07 May 2026 13:39:00 GMT
- 相关标的：600519.SH
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiTkFVX3lxTE91THpaY2NGcUpoaWZHODBoV2lDbWRXMmtSMlBQZWVydllETnd1QWdkYkcwWDhmOWdnZUNZbVAtOTlJbEt6enRJRndvaFVyUQ?oc=5
- 摘要：贵州茅台：这些“会所”，都是假的 海报新闻

### 8. 贵州茅台：未接到换帅消息 袁董到退休年纪已属“超期服役” - 每日经济新闻

- 来源：每日经济新闻
- 日期：Thu, 07 May 2026 04:22:00 GMT
- 相关标的：600519.SH
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiX0FVX3lxTFBQUkhjWEx0YTBOMGJiZDJ0S3cyTUhhNVY5c0dkWEM0cGRXcUFKd2l5M2pzY2xocUZfWGpBSmhLYXBiaG1pNHo1ckdnUlBkeXdSXzIzS1E3WUNTZTBfdExV?oc=5
- 摘要：贵州茅台：未接到换帅消息 袁董到退休年纪已属“超期服役” 每日经济新闻

### 9. 公募对贵州茅台的调仓出现分歧，刘格菘、莫海波逆势加仓| 基金放大镜-腾讯新闻 - qq.com

- 来源：qq.com
- 日期：Thu, 23 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiVkFVX3lxTE1JX3UyTWhOaEFuWGVjOUtCYWI1YVdkX3k1c252aHYtdzJBZ0c1bmVUckZOSWIwYTBqREY5Sm0wWXlSQUtQRENnTnVCU25XamEzTlU4b1p3?oc=5
- 摘要：公募对贵州茅台的调仓出现分歧，刘格菘、莫海波逆势加仓| 基金放大镜-腾讯新闻 qq.com

### 10. 贵州茅台已经算不错了中国中免，上海机场，惨多了 - 新浪网

- 来源：新浪网
- 日期：Fri, 17 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiY0FVX3lxTE5LU1NhalBPZDJqX1J4ZzNXR2lueWNkSnBJNk1rbDVBdS0tMUZTalZtdlZ1cTU2Wi1qaXdTM3JsMjI0RUFsS1VSNnVYd3g3OFc0RUliRVNTZE43Ymo2cUItNXFWTQ?oc=5
- 摘要：贵州茅台已经算不错了中国中免，上海机场，惨多了 新浪网

### 11. 股票行情快报：贵州茅台（600519）5月15日主力资金净卖出6.52亿元_主力研究 - 证券之星

- 来源：证券之星
- 日期：Fri, 15 May 2026 11:38:30 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTE5rWms1S3pkOFFZTVdnS1RidlUyWlZhd19BSG1JT21kcDhCRTlTbWdtd2tUeThXblJ1UU9OVl9hQUgwd1UtcTJoQ3BBRHFtcVhLUVhrbV9FaWdhY3p3emUwaF9B?oc=5
- 摘要：股票行情快报：贵州茅台（600519）5月15日主力资金净卖出6.52亿元_主力研究 证券之星

### 12. 股票行情快报：贵州茅台（600519）5月12日主力资金净卖出11.23亿元_主力研究 - 证券之星

- 来源：证券之星
- 日期：Tue, 12 May 2026 11:44:30 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTFBoeWRSWmh1RS1zSmhDVDRaM2pHb1ZPMmo2SThaZ1AyeGwzcy0ya2tmVlFmYlF5VnFHVVJmOWhlRU0yNnhqaldtUGFYTHZFbGQ0eFVkS0lTUWlVT0RTTFFYVWx3?oc=5
- 摘要：股票行情快报：贵州茅台（600519）5月12日主力资金净卖出11.23亿元_主力研究 证券之星

### 13. 股票行情快报：贵州茅台（600519）5月13日主力资金净卖出11.78亿元_主力研究 - 证券之星

- 来源：证券之星
- 日期：Wed, 13 May 2026 11:19:14 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTE5uR2ZubmZoUzFwYzhYNnI4TXRZWnpGMW1HYURoT1dUcHNTMHdFZTdpUUx3dnNiRnB1Y3ZNcEt1anhLX1FKcXlmeG01WWlSa3BrRTJBQk56eGpMcTRHV3lZdG9n?oc=5
- 摘要：股票行情快报：贵州茅台（600519）5月13日主力资金净卖出11.78亿元_主力研究 证券之星

### 14. 贵州茅台2025年营收净利双降，拟派发350.33亿元现金红利_公司新闻_财经 - 证券之星

- 来源：证券之星
- 日期：Fri, 17 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYEFVX3lxTE1XS0xJTEN4VldnTkp0T0JScWpGTmE3N2luWHdmZklVQmhTcS10TUlqcGtzTnh5RWFhYWQ0WWZmVTJ0WllmNE0tNDVFU2ZtaEI3SW14NG9DbVM4WmhHTWVjYQ?oc=5
- 摘要：贵州茅台2025年营收净利双降，拟派发350.33亿元现金红利_公司新闻_财经 证券之星

### 15. 5月14日上证50ETF万家基金份额减少30万份，重仓股贵州茅台、中国平安、紫金矿业_基金提醒_雷达 - 证券之星

- 来源：证券之星
- 日期：Thu, 14 May 2026 22:31:15 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTFBYN1VFSXdub2FrVU55MWRLcktwMjQ5SkMzZV9PTDNiY0xRbGZ4SmFib2tyaUozclFuVWhmdTFOTTRqZm1qUEdzdU9PdnBvejZYVC13YTJZWVBvQTNQQl81YjV3?oc=5
- 摘要：5月14日上证50ETF万家基金份额减少30万份，重仓股贵州茅台、中国平安、紫金矿业_基金提醒_雷达 证券之星

### 16. 5月14日上证50ETF博时基金份额减少30万份，重仓股贵州茅台、中国平安、紫金矿业_基金提醒_雷达 - 证券之星

- 来源：证券之星
- 日期：Thu, 14 May 2026 22:31:17 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTE80Yy1ZdFlMS1VaaU9DZFNzS3dvRlRGLXVsQjViaDVWeXFSVVo4OEh1YXp6eUpDVy1QdFZMQ0t2ZnBiU1Utd0VtX2pNYU9ma0dDdTRGRlNMUEVRZnBuckJyemZ3?oc=5
- 摘要：5月14日上证50ETF博时基金份额减少30万份，重仓股贵州茅台、中国平安、紫金矿业_基金提醒_雷达 证券之星

### 17. 5月14日上证50ETF工银基金份额减少120万份，重仓股贵州茅台、中国平安、紫金矿业_基金提醒_雷达 - 证券之星

- 来源：证券之星
- 日期：Thu, 14 May 2026 22:31:33 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTE5WcExPZ1lfNmg1WXhCa3c0M1ZqakZBRnBOWUI5VWZIWHBLZG15TjB5bFI5RTNsOGh4UFJqUmYyRTlURG5UaEdoYU15NktKVzZDOW00alJRUkdicmFHZFQzY1VB?oc=5
- 摘要：5月14日上证50ETF工银基金份额减少120万份，重仓股贵州茅台、中国平安、紫金矿业_基金提醒_雷达 证券之星

### 18. 5月13日上证50ETF万家基金份额增加90万份，重仓股贵州茅台、中国平安、紫金矿业_基金提醒_雷达 - 证券之星

- 来源：证券之星
- 日期：Wed, 13 May 2026 22:31:57 GMT
- 相关标的：600519.SH
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTE5XM0xjcW84RXhjeEtFLUJQLWJVNFNRbEl6YkhFeE8wTXp4UENIaW5YWHBHb25HRm1WUmY5MWpSZjRBT0hyVDVkSHMxaHpyMjlpZ2lKXzByU3hQSjlzelNocjJR?oc=5
- 摘要：5月13日上证50ETF万家基金份额增加90万份，重仓股贵州茅台、中国平安、紫金矿业_基金提醒_雷达 证券之星

### 19. 5月15日上证180ETF华夏基金份额减少500万份，重仓股贵州茅台、紫金矿业、中国平安_基金提醒_雷达 - 证券之星

- 来源：证券之星
- 日期：Fri, 15 May 2026 22:31:12 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTFBJOWtvUlB4ZnFxY1JJN1JuTDNtNTg4bXBsZFhMZG1uMmpDcnM0QWt5anJaU0RRa1RIb3BERkhITWNBYTBOMklNN29PZXNXd3lhcVZrNXBHUlVQYndJR25mdGx3?oc=5
- 摘要：5月15日上证180ETF华夏基金份额减少500万份，重仓股贵州茅台、紫金矿业、中国平安_基金提醒_雷达 证券之星

### 20. 5月15日上证50ETF建信基金份额增加100万份，重仓股贵州茅台、中国平安、紫金矿业_基金提醒_雷达 - 证券之星

- 来源：证券之星
- 日期：Fri, 15 May 2026 22:31:20 GMT
- 相关标的：600519.SH
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTE52bVY0UzR5eFJ6ekwtLUoyWjF1LWNxdGpXd0VyUnhzUXlEY0hKSWkxV1ktOG1nREdWZ3FOZklNaHpDSldBODhqUjZoMlgtRWg4Uk92VGlUVFh0cTJkckhOMzN3?oc=5
- 摘要：5月15日上证50ETF建信基金份额增加100万份，重仓股贵州茅台、中国平安、紫金矿业_基金提醒_雷达 证券之星

### 21. 贵州茅台上市以来首现年度营收下滑，分红创历史新高｜财报见闻 - 华尔街见闻

- 来源：华尔街见闻
- 日期：Thu, 16 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiU0FVX3lxTE5fNTVYaDRFclpSQXB6TzJIOV9LVTRTWFRhNVlDNk40STBER1hRY1c2dUpPZm5DTVc4bVNmWkJEUkhrTVpkNXVHSmFpNE1mQTRpVlJZ?oc=5
- 摘要：贵州茅台上市以来首现年度营收下滑，分红创历史新高｜财报见闻 华尔街见闻

### 22. 贵州茅台首次年收入和净利润双负增长 2025全年分红比例提高4个百分点 - Caixin

- 来源：Caixin
- 日期：Fri, 17 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiZEFVX3lxTFB3Qk8zNWhxV3RfSzBianAzaWNKRUhubU5fVGhESzNJZXlKYjRNTi11STMyb042U3lPYmtCZ0VDbjZjRnpNZzFHNWc2X3JtLU1MZnc3VmlzX0tfRk5iYXNuOEtvZkQ?oc=5
- 摘要：贵州茅台首次年收入和净利润双负增长 2025全年分红比例提高4个百分点 Caixin

### 23. 财报观察室丨以“短痛”换渠道健康，白酒能否迎来拐点？ - 新京报

- 来源：新京报
- 日期：Thu, 07 May 2026 10:18:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiZEFVX3lxTE5kQTFWU2RsSXc4V2RZc2ZyQWI1S2k5ZG51OHU4SURhSk81ZWVSNW5xZERQcFg5ODFjOTRXLW85MW5YYnA5Y01kUGE5ZFpYc2dnXzNHZWx2Vy05NmxlVEdHNzBWNm0?oc=5
- 摘要：财报观察室丨以“短痛”换渠道健康，白酒能否迎来拐点？ 新京报

### 24. 突发！贵州茅台上市20多年首次年度营收、净利双降！ - 东方财富

- 来源：东方财富
- 日期：Fri, 17 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiZ0FVX3lxTE81Vk5iTWN5ZmtIRFpyM2FPNFJLYVhETEFldzZnVkc3ZkNSRElxVmZXVUUyTUZ5LXhwY2QxZkZ4bHZpZnl6QjUzZTF0T0wxeUsyZ3E3dFJrVjhXOUpjM0hzUVR6VFVQTHc?oc=5
- 摘要：突发！贵州茅台上市20多年首次年度营收、净利双降！ 东方财富

### 25. 茅台三季报保持正增长 张坤逆势加仓｜酒业财报观察 - 21财经

- 来源：21财经
- 日期：Wed, 29 Oct 2025 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMijwFBVV95cUxOa29JX2RvYXFOYzlUeG9ndUtzMkxLOC02U1hWbkxjWVotUzRSdDg3a1IyWl9FeGF4QThYdTM0TVU4bklNUXBtNkNkSnN5dHYwendzc3huaXNQQ3JDUC05Ml9pVHFzVU9Zdl8ydGZ0bUM2d1lHVXVzOWFhNXFDRHZmUUllNEctVF9rV0RZcWItRQ?oc=5
- 摘要：茅台三季报保持正增长 张坤逆势加仓｜酒业财报观察 21财经

### 26. 去化落地！重返A股股价榜首，贵州茅台剑指2030元 - 证券市场周刊

- 来源：证券市场周刊
- 日期：Tue, 21 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiZkFVX3lxTE1xZk1lSi1tYUNXR0NTWjY3S1pNTXhUZW1kM0JTcFkwczRuTmRWdTJfSTBMNV9jZjhVZmNIdXprdk85Q3VYa0RRT1VIYnV1RWhhMUJGanpMTDlhRzRaWUJ5RW42YVZRZw?oc=5
- 摘要：去化落地！重返A股股价榜首，贵州茅台剑指2030元 证券市场周刊

### 27. 贵州茅台2025年营收、净利双降 - 中国基金报

- 来源：中国基金报
- 日期：Fri, 17 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiekFVX3lxTE5Zek1Wekh3UTRleHBSS0pQT0hpMEZLYUNHYjhuOGpaTm5YSDRMNnRYWE42djZZZDJNamZZVDVKN2FPNW5CWjFCcy1veHEwOThWWHhSblAtdDdNaXAwN3p2dnNzUGU0cndiX0ZlMHhrdDlRV3lrTnAxS2pR?oc=5
- 摘要：贵州茅台2025年营收、净利双降 中国基金报

### 28. 2025年茅台财报分析和四季度茅台业绩大幅度下跌核心原因 - 雪球

- 来源：雪球
- 日期：Fri, 17 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiUEFVX3lxTE94aEItY0pQNFFTSEJlRzZGTzNONVdVU0FpT3plRWF4ZGJIdko3VVc1ekxIcjV2ME1mRXZydmxWTnZZR1NpZ1VmenduQ013eE0x?oc=5
- 摘要：2025年茅台财报分析和四季度茅台业绩大幅度下跌核心原因 雪球

### 29. 贵州茅台上市至今首现年度营收、净利下滑：2025年净利润823亿元同比下降4.53% Q4业绩低于预期 - 财联社

- 来源：财联社
- 日期：Thu, 16 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiSEFVX3lxTE1EMEZUZVRrQjNuWUtUbUJmX2xUNHVvQzhDQUFYXzZxdkh2dVpOMmdOdE5XdkZsbGxEakpCUFA5ZmtaOGFkcDBTUA?oc=5
- 摘要：贵州茅台上市至今首现年度营收、净利下滑：2025年净利润823亿元同比下降4.53% Q4业绩低于预期 财联社

### 30. 贵州茅台上市以来首现业绩双下滑，拟派350亿元现金“红包” - Jiemian.com

- 来源：Jiemian.com
- 日期：Thu, 16 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiWEFVX3lxTE5Mb1dwVWxIdVJwT0J1ZjVXOVh4cjhrUTRNelB3UzNmZXlKTUtaYUoxMU5qUkRRRnJaNkxqOHN3dWZkNnk3QnRSTEVsUnVSRFJ6bmFNSkpFbW8?oc=5
- 摘要：贵州茅台上市以来首现业绩双下滑，拟派350亿元现金“红包” Jiemian.com

### 31. 茅台上市以来首现业绩双下滑，茅台真没人喝了？ - thepaper.cn

- 来源：thepaper.cn
- 日期：Mon, 20 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiXkFVX3lxTE9DWi1RZUVhYVY1eU1MaHVPNGx1MGg0Mi1sX3lfZ0ZzRVNmUEFjeFpXY002UVR0ZlBoMlR4T0ZSYnVma2dRS012UGJFMEI0a3U2SVFXd25JdVc5TmowV0E?oc=5
- 摘要：茅台上市以来首现业绩双下滑，茅台真没人喝了？ thepaper.cn

### 32. 贵州茅台Q1营收、净利双增，“i茅台”营收达215亿元，占比达40% | 财报见闻 - 华尔街见闻

- 来源：华尔街见闻
- 日期：Fri, 24 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiU0FVX3lxTE9aZ0RrZ1N1eTFIazFOVEhHa2ttcEZBY083dE9uZUhRTlhYOTNsOWZ3WTdVcEFKbXJRV09OOXltUFNOYVQyYzI3TzVJd1NORGJ0R1BF?oc=5
- 摘要：贵州茅台Q1营收、净利双增，“i茅台”营收达215亿元，占比达40% | 财报见闻 华尔街见闻

### 33. 贵州茅台2025年报 1，年度业绩：2025年营收1688.38亿元（同比-1.21%）、归母净利润823.20亿元（同比-4.53%），上市... - 雪球

- 来源：雪球
- 日期：Fri, 17 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiUEFVX3lxTE9RMWU2RmNadUltQUswLXRSLXRHRmFmSTF1ZjJzV3Q5UHcxVEpvdnlZeUNNb0xvcmJCNmlhUUtxcl82SGRxNUpXVktTNEJRQTVq?oc=5
- 摘要：贵州茅台2025年报 1，年度业绩：2025年营收1688.38亿元（同比-1.21%）、归母净利润823.20亿元（同比-4.53%），上市... 雪球

### 34. 日赚3亿！贵州茅台一季度净利增1.47%至272亿元，i茅台营收大增267% - thepaper.cn

- 来源：thepaper.cn
- 日期：Fri, 24 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYEFVX3lxTE5KQ3hFRVRGMW1LM1puYWdoeWFKdEppempfcHpiNElJMWRaTXdHSUZINFdrVFB6R3VXN3FtcEM2RUluRW1xbHdPc3RrdFU0WXdzRVE0Vmg0TE5HVGY2elFvSg?oc=5
- 摘要：日赚3亿！贵州茅台一季度净利增1.47%至272亿元，i茅台营收大增267% thepaper.cn

### 35. 贵州茅台上市以来首现营收净利双降，首次未完成既定目标 - thepaper.cn

- 来源：thepaper.cn
- 日期：Fri, 17 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiXkFVX3lxTE9CZzl3V282QUtpTDBVeUlpUGZmdjdNeERQeGpqSER4ZTVHRnZPYU8ySThoTDdWaXluMjRRM0x1enkxT2REYzA1aF83OHlGcGdrLU5idnp6YW5DcDdHb2c?oc=5
- 摘要：贵州茅台上市以来首现营收净利双降，首次未完成既定目标 thepaper.cn

### 36. 贵州茅台回应热点：未来是否存在大幅修调以往业绩报表的风险？飞天会否再提价？ - thepaper.cn

- 来源：thepaper.cn
- 日期：Mon, 11 May 2026 12:18:00 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiXkFVX3lxTE0yTnl0TEx2RkVEeXpYd0tVdFAtdFRxZnc1LTZqRE1hS0N1TzF0MEtmdDQ4MEQ3eFlNb2FlWTVnMjFkYzk3WnVZdGxIWU93RjJIZXRFNGFEeXNWR0QzdWc?oc=5
- 摘要：贵州茅台回应热点：未来是否存在大幅修调以往业绩报表的风险？飞天会否再提价？ thepaper.cn

### 37. 茅台上市以来首次年度负增长，未公布2026年经营目标 - thepaper.cn

- 来源：thepaper.cn
- 日期：Fri, 17 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiXkFVX3lxTFBhSEwtLU93eTN6VVJTWkZvYXE5SGtaLWpoYUZ5MlZkWkw1UTFtWmtOelVlcmNCS0pYVndKY2V5eVhwelhfQmhtVFl1aVpNQUF2X1ZhSXVsU2puZ0ZZZHc?oc=5
- 摘要：茅台上市以来首次年度负增长，未公布2026年经营目标 thepaper.cn

### 38. 贵州茅台，首次下滑 - thepaper.cn

- 来源：thepaper.cn
- 日期：Sun, 19 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiXkFVX3lxTE15OEdFVXlxR1h3Z3d2TlVmZ0tKV0tna2JtZk9xMXc5N1hxMFVGS2F2YnY5WVdYMkE3Q1dXbHhmVGtwTGIyZUszWXVJUExJTXlfSjhyai1TNjc0dFBQU1E?oc=5
- 摘要：贵州茅台，首次下滑 thepaper.cn

### 39. 上市25年贵州茅台首现收入利润双降，四季度业绩跳水_IPO观察_新股 - 证券之星

- 来源：证券之星
- 日期：Fri, 17 Apr 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTFB6bXdtTy1oaHBMcjRWTExDTFJXZU1hem5HdHdDSUd3RnV1UnNDNF9ScUswNHNPTVZsZ0NHMnA3SDh0LVZTazFsd01nbkktLUwwOVNXcWh4QkJqdF9lMHhtVTJ3?oc=5
- 摘要：上市25年贵州茅台首现收入利润双降，四季度业绩跳水_IPO观察_新股 证券之星

### 40. 贵州茅台，中期分红300亿元！斥资15亿至30亿元，回购注销股份 - 证券时报

- 来源：证券时报
- 日期：Wed, 05 Nov 2025 08:00:00 GMT
- 相关标的：600519.SH
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiV0FVX3lxTFBONklydnNuYy1WNy1JOTZ1TzdwM1FOTmNNRkxMWnRNaUYxM1pDT2RNN0dwdUVfdGI3dUx4Tlg2aGVlQUZMQ3hIT0lBOTZUV3QweTRUZmFNcw?oc=5
- 摘要：贵州茅台，中期分红300亿元！斥资15亿至30亿元，回购注销股份 证券时报

### 41. 手握2108亿元，茅台大手笔回购、中期分红：30亿+300亿 - 新浪财经

- 来源：新浪财经
- 日期：Thu, 06 Nov 2025 08:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMihwFBVV95cUxQSm9kWVU5YWt1M2lwWVdDQkJKWFo1ekRWNnhEV3FMRFFuLVhDZ1FrM3BNc3NnczJZVU1hZl9DbUh3MXlHSWd1VGtSdjRHNXIxNTlMQjJDeGFHUUw2MmxRQ0gxQ2h0cjNGWDFWb1BWazVMRDdFVTkyZmVkX3pMNm5EUXZLZFJQVzQ?oc=5
- 摘要：手握2108亿元，茅台大手笔回购、中期分红：30亿+300亿 新浪财经

### 42. 贵州茅台：股东大会通过2024年度利润分配方案 拟10派276.24元 - 第一财经

- 来源：第一财经
- 日期：Mon, 19 May 2025 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiU0FVX3lxTE05NFJ5ekt2Q1poM1hyak5ZY29rXy1PMW9KcHNCcEd1cHl6d19SWVlUOFl6MDI0VGg0b1B6YkZtNF9UN2lpd0RmTzlFNkNqTGYwYjNZ?oc=5
- 摘要：贵州茅台：股东大会通过2024年度利润分配方案 拟10派276.24元 第一财经

### 43. 茅台董事长陈华：茅台不会损害投资者、渠道商和消费者权益 - 21财经

- 来源：21财经
- 日期：Sat, 29 Nov 2025 08:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMijwFBVV95cUxNZ25mYnJWMVp5NUlmZmRTTkh3TjdLaU9YVTUycUhOWHBBQ190NDNMbWVHcXJSR29KeU1sS2VWeXJzMFZBeXpnbDVTb0RkVE9rX050RU5MZWpZR1R4MUN0T1ZOWG5GSExxWmQ1SDNsWHlSc1plcXZqODJCV0FVbC0xSm8zMmtGcXhvdGRoT19UMA?oc=5
- 摘要：茅台董事长陈华：茅台不会损害投资者、渠道商和消费者权益 21财经

### 44. 回购+300亿分红！贵州茅台打出“重磅组合拳” - 财联社

- 来源：财联社
- 日期：Wed, 05 Nov 2025 08:00:00 GMT
- 相关标的：600519.SH
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiRkFVX3lxTE13NEdxbnY0RVJuNXlqbmM1bFZrWWpFWVNpS2FQMnZMUW43YlJMRzAyREYwMHp2eC14cU5pQTBmS3FUbkYzd1E?oc=5
- 摘要：回购+300亿分红！贵州茅台打出“重磅组合拳” 财联社

### 45. 分红刷新纪录，茅台向行业内外释放信心 - 京报网

- 来源：京报网
- 日期：Tue, 20 May 2025 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMickFVX3lxTE8yTTFrRXRhTDduYWVhZE05N1BUNlBDM2hGbjlWcGtrR05jUXR1OVZFNHhPR0hjMlliMTZJaERGZVFyS2pxc18wYmRwOE5Nd0U1M0ZVbTZPODdJbDJCejExQTNIZVEyeVpGNHlzNXJ1MEdXZw?oc=5
- 摘要：分红刷新纪录，茅台向行业内外释放信心 京报网

### 46. 茅台放大招！300亿分红+30亿回购，打响年内第二轮市值管理组合拳 - 国际金融报

- 来源：国际金融报
- 日期：Thu, 06 Nov 2025 08:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiX0FVX3lxTE03SWc2cWF2d1p1ZDJESVozamw4MklxLW10V2xRaEtXakNhR01mbTA2Njk3eXJfbGEzTnMySDJFUHhrSlRCTEJMeFRNRHVuNHBHYmZfcy1XS1k3cVEzanVV?oc=5
- 摘要：茅台放大招！300亿分红+30亿回购，打响年内第二轮市值管理组合拳 国际金融报

### 47. 贵州茅台2025中期派红逾300亿元 - qq.com

- 来源：qq.com
- 日期：Wed, 05 Nov 2025 08:00:00 GMT
- 相关标的：600519.SH
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiVkFVX3lxTE5IV1VTSTB1c1BFVEVLbDRfSkxUV3hlN25GN01OTzl5UC1VNWJMWlg1SDhXZEZIanhQakR3OTlDQnE1clNodmdSOUNvUEhtTm5rdXdtUFR3?oc=5
- 摘要：贵州茅台2025中期派红逾300亿元 qq.com

### 48. 贵州茅台副总经理、财务总监、董事会秘书蒋焰被查！ - 新浪财经

- 来源：新浪财经
- 日期：Fri, 13 Mar 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMihAFBVV95cUxOb1JkR284a0ZKRWpkSl8xLVZWRk40ZE9vX253bkp1YVhPNUYzOW9iVXVDeXJvSTF4Z1pNbldsdHlXZ1VORm8tU0lzUmVULWdkdHV2dzNSUk8xcDZjVzQ2b3IxVG9OX1ZDcUVQLWpZQVN3bVJrT2s4bnBENi1CSkZzZW9FOVc?oc=5
- 摘要：贵州茅台副总经理、财务总监、董事会秘书蒋焰被查！ 新浪财经

### 49. 股东会前的这些细节和环节，茅台诠释了“鱼与水”的共生关系 - eastday.com

- 来源：eastday.com
- 日期：Fri, 28 Nov 2025 08:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMigAFBVV95cUxQckQzVFVlRlAxVlgydDRDb1pKU242ai1mQzNJXzNZMk9zT3ZHNnRzbWZVVGxhdmdXbFRGTkVrMFA0XzR5MFN2VnZ4ODFMR1NfQkJXZVA3Nk9OYTlZQ3FLZmxXYnVIVExtZl91QjdYQkdVWnBSaVdJalZET1BGbXpxOA?oc=5
- 摘要：股东会前的这些细节和环节，茅台诠释了“鱼与水”的共生关系 eastday.com

### 50. 贵州茅台上调2024年年度利润每股分红金额 - 新浪财经

- 来源：新浪财经
- 日期：Fri, 13 Jun 2025 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMigAFBVV95cUxQR0V3SzlmeXRMWXZicGdsajROZzN1WW5JVjBZQ2tOa3V2VExmcTNELWNncmhQVWlnblpwNFR4VG5SenlEWDNqVmlHQ2V5M25yclAzckhLc3VXbnRlMHZJQjh1dzMyRld4Y3hPRFJjbXRCZnI5NWpiY3VhdWRRdTBIVw?oc=5
- 摘要：贵州茅台上调2024年年度利润每股分红金额 新浪财经

### 51. 3200亿现金托底，美的集团“不差钱”再抛百亿回购 - 21财经

- 来源：21财经
- 日期：Wed, 18 Jun 2025 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMihgFBVV95cUxPd2hrOC03bkpENkt2cFFNZ0diRHN6czdLYWFZaXExOE53RU5qbjdBUnlLa0dCR3NCX3pSMkw0OEV0SG50UTZXU2phb2lKZHgtbVlXVUM3UG15aFpmWU9Pak4yY05SYm03RnBlaGtKY2RORWFWVkxTejlYUGswQ1daUDNMajZhZw?oc=5
- 摘要：3200亿现金托底，美的集团“不差钱”再抛百亿回购 21财经

### 52. 茅台董事长陈华股东大会“首秀”：茅台未来信心十足 机遇始终大于挑战 - 证券时报

- 来源：证券时报
- 日期：Fri, 28 Nov 2025 08:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiXEFVX3lxTE1mQnNlcEphRHhGRTFEdkxzZnN0YnRQV3Q2SGZrQXN2TzFLNUFndVROV2FzVGJBWEZkNmZyYzNoQ1owUUhhRXR0ZzdXUkJ5bTJ0M0VtR1VkU2tFdExR?oc=5
- 摘要：茅台董事长陈华股东大会“首秀”：茅台未来信心十足 机遇始终大于挑战 证券时报

### 53. 直击茅台股东大会，猛料不止“晚宴茅台换果汁” - qq.com

- 来源：qq.com
- 日期：Tue, 20 May 2025 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiVkFVX3lxTE9Dd1ZURjZMaExUbGRwZmp0UndEQ3NSRFhxc2JrWVdabXBKTU00aU5relF0OS1BRDRNQkpGbE9ESlVvSWpHREVrY0lRckxmQW5XT1lQdmp3?oc=5
- 摘要：直击茅台股东大会，猛料不止“晚宴茅台换果汁” qq.com

### 54. A股回购持续升温，龙头企业大额回购显成效 - 新浪财经

- 来源：新浪财经
- 日期：Sat, 16 May 2026 02:42:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMieEFVX3lxTE45YW01eXliUU8xbzRaMkNTbEJycTVkakdkWGlpSDhkX0tfSEsyN2lYYmdJYVFWVHpuXzJoY2NqeW40cmFOanZtZFdOV2FmWmhsQ3B0Nklza21XSDlWVDFPejhKSnpnRVoxMXY3VVFsQkwzb3RiZDBpTA?oc=5
- 摘要：A股回购持续升温，龙头企业大额回购显成效 新浪财经

### 55. 大手笔！超高股息率个股曝光，这3股超10% - 证券时报

- 来源：证券时报
- 日期：Fri, 03 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiXEFVX3lxTE1aTGZxTVBKa2xjZlFWY0I2akNtVmVQM2h4c2NDcHNGeldlRGJUQUR2YXlIYWRGSlkzUXc5OEZHTWc2Njc1QnRCVmFhQTRESGRGelAxWTUxYWpTbHA3?oc=5
- 摘要：大手笔！超高股息率个股曝光，这3股超10% 证券时报

### 56. 突发！贵州茅台董秘蒋焰被查！两周前，五粮液的原董事长曾从钦也被留置调查了！ - 新浪财经

- 来源：新浪财经
- 日期：Sat, 14 Mar 2026 07:00:00 GMT
- 相关标的：600519.SH
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMieEFVX3lxTE1BSndNSU0zZ21YWlBRZ0F2X2tOeTRLTWxydHRLOHRnbXVhZHQ1SzBrUkI0UTFfRDU3Z2JiVlByX3RLWEg2OGVIUmxQVlgxNmFUanlmQUdubnh3d01sR01xTDQ5bjY2bGtOekxCODJoeDdUakN5b19zdA?oc=5
- 摘要：突发！贵州茅台董秘蒋焰被查！两周前，五粮液的原董事长曾从钦也被留置调查了！ 新浪财经

### 57. 姚安娜成珍酒李渡申遗大使；泸州老窖增持已出资90%｜观酒周报 - 21财经

- 来源：21财经
- 日期：Mon, 16 Jun 2025 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMijwFBVV95cUxQTi1lQWR0T2RfemZtblhOUF9oZkdXTzM3TUlOMnlITnBxNi0ySnFWQWRjWG83azFLbWZKVU9CSklvQkc4TWdFOWI4VlhKS25aSXFwbFJrWFBUa0w2ZWc5VjVaOTRocS0tYnZRYkV5aV9iUEV1VmhvVERMdlZCS1QzSjBJX0w4dXJlVHRWZVRlSQ?oc=5
- 摘要：姚安娜成珍酒李渡申遗大使；泸州老窖增持已出资90%｜观酒周报 21财经

### 58. 贵州茅台：茅台酒终端动销环比增长态势明显 - 证券时报

- 来源：证券时报
- 日期：Thu, 06 Nov 2025 08:00:00 GMT
- 相关标的：600519.SH
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiXEFVX3lxTE9veUN3X0tCSGt2blhJSm1zelkwMGF5MlBLTlFKUWQxTk9TcUV6V0JNTURnQTd0VUNlWDJBTG1na0ZOeHdRN0x5MU9qRV82Sjc1TFUyOVNneDdyTHRv?oc=5
- 摘要：贵州茅台：茅台酒终端动销环比增长态势明显 证券时报

### 59. 茅台业绩说明会34问：望市场化改革得到广大股东支持 - 新浪财经

- 来源：新浪财经
- 日期：Mon, 11 May 2026 11:44:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMibkFVX3lxTE5JeE5neGFUV3lRT0lPZVVNQTZHOVRibE9xNFBmalBqeTB6U1JBMjkzYi1ocVAwWHZBN2J4VHl5YUFvdURyNWNUWEVjZUh1ZzVZSWo2Z2IxaGl6QXdBTExWTG1feUMxRlI5WlZsaWZR?oc=5
- 摘要：茅台业绩说明会34问：望市场化改革得到广大股东支持 新浪财经

免责声明：本系统仅用于课程演示和市场信息解读，不构成投资建议。