# 个人持仓新闻解读与风险提醒报告

生成时间：2026-05-17 15:40:59

> 本报告由多智能体流程生成；如启用 LLM 精修，会在规则分析结果基础上进行语言组织。

## 持仓快照

- 账户基准货币：CNY
- 数据日期：2026-05-17
- 示例持仓数量：1
- 示例总市值：56,460.00

## 行情快照

- 000657.SZ：2025-08-13 至 2026-05-15，收盘价从 16.98 变为 56.46，变化 232.51%。

## 技术图表

### 000657.SZ
K 线叠加 MA5 / MA10 / MA20：
![000657.SZ K线均线图](outputs/charts/000657_SZ_kline_ma.png)

MACD：
![000657.SZ MACD图](outputs/charts/000657_SZ_macd.png)

成交额（若数据源未直接提供成交额，则按均价×成交量估算）：
![000657.SZ 成交额图](outputs/charts/000657_SZ_amount.png)

## 新闻抓取概览

- 本次纳入新闻数量：62 条
- 抓取来源类型：google_news_zh_rss 62 条
- 关联标的分布：000657.SZ 24 条
- 情绪/风险标签分布：neutral 47 条，positive 11 条，risk 4 条

## 最近财报与公告概览

- 本次纳入财报/财务相关公告数量：7 条
- 最新一条：2026-05-08 中钨高新:关于参加海南辖区上市公司2025年年报业绩说明会暨投资者网上集体接待日活动的公告

## 多智能体分析结果

## 新闻解读智能体

样本覆盖：24 条直接相关资讯；标签分布为 {'risk': 4, 'positive': 5, 'neutral': 15}。

核心主题归纳：
- 压力主题：4 条资讯被识别为风险类，集中在业绩波动、资金净卖出、管理层/治理事件、行业需求与价格体系变化。
- 支撑主题：5 条资讯被识别为正面类，主要涉及分红、回购、扩产/投资、价格变化、季度增长或订单改善。
- 可量化线索：净卖出5.68亿元；净利润为12.81亿元、同比较去年同期上涨29.20%；净卖出4.94亿元；净卖出10.42亿元；净利预增超256%；净利大涨264%；净利润同比增长264.44%；净利润同比增长264%。

代表性证据链：
- [risk] 中钨高新（000657）5月14日主力资金净卖出5.68亿元_主力研究 - 证券之星（证券之星）：中钨高新（000657）5月14日主力资金净卖出5.68亿元_主力研究 证券之星
- [positive] 中钨高新：控股子公司拟投资1.825亿元新增高端微型精密刀具年产能1.5亿支 - 东方财富（东方财富）：中钨高新：控股子公司拟投资1.825亿元新增高端微型精密刀具年产能1.5亿支 东方财富
- [neutral] 中钨高新(000657.SZ)：控股子公司拟实施中粗碳化钨粉智能生产线技术改造项目 - AASTOCKS.com（AASTOCKS.com）：中钨高新(000657.SZ)：控股子公司拟实施中粗碳化钨粉智能生产线技术改造项目 AASTOCKS.com
- [neutral] 中钨高新2025年年报净利润为12.81亿元、同比较去年同期上涨29.20%-腾讯新闻 - QQ News（QQ News）：中钨高新2025年年报净利润为12.81亿元、同比较去年同期上涨29.20%-腾讯新闻 QQ News
- [risk] 股票行情快报：中钨高新（000657）5月12日主力资金净卖出4.94亿元 - 搜狐网（搜狐网）：股票行情快报：中钨高新（000657）5月12日主力资金净卖出4.94亿元 搜狐网
- [neutral] 中钨高新早盘快速涨停_新浪新闻 - 新浪网（新浪网）：中钨高新早盘快速涨停_新浪新闻 新浪网
- [risk] 股票行情快报：中钨高新（000657）5月12日主力资金净卖出4.94亿元_主力研究 - 证券之星（证券之星）：股票行情快报：中钨高新（000657）5月12日主力资金净卖出4.94亿元_主力研究 证券之星
- [neutral] 中钨高新：金洲公司拟投资1.83亿元实施印制电路板用高端微型精密刀具技改扩能项目 - 新浪财经（新浪财经）：中钨高新：金洲公司拟投资1.83亿元实施印制电路板用高端微型精密刀具技改扩能项目 新浪财经
- [neutral] 中钨高新：5月12日融资买入3.66亿元，融资融券余额30.25亿元 - 搜狐网（搜狐网）：中钨高新：5月12日融资买入3.66亿元，融资融券余额30.25亿元 搜狐网
- [neutral] 中钨高新：目前公司没有六氟化钨产品公司主要向相关客户提供生产六氟化钨所用到的原材料钨粉 - 东方财富（东方财富）：中钨高新：目前公司没有六氟化钨产品公司主要向相关客户提供生产六氟化钨所用到的原材料钨粉 东方财富
- 其余 14 条直接相关资讯见新闻明细。

## 财报公告智能体

公告样本：7 条，其中年度报告 2 条、季度报告 2 条、分红/利润分配 1 条、业绩说明 2 条。

公告解读框架：
- 年报线索：最新年报相关公告为 2026-04-27《中钨高新:2025年年度报告摘要》。
- 季报线索：最新季报相关公告为 2026-04-27《中钨高新:2026年一季度报告》。
- 股东回报线索：存在利润分配/分红安排公告，说明现金回报是当前市场关注点之一。
- 沟通线索：业绩说明会公告意味着管理层将回应经营质量、增长目标、渠道库存和价格体系等问题。
- 新闻中提取到的财务数字：净卖出5.68亿元；净利润为12.81亿元、同比较去年同期上涨29.20%；净卖出4.94亿元；净卖出10.42亿元；净利预增超256%；净利大涨264%；营收4万亿、最高暴涨6136%；净利润同比增长264.44%；净利润同比增长264%。

分析师式追问：
- 年度收入和净利润变化是否来自销量、价格、产品结构、渠道投放或费用率变化。
- 高分红和回购是否足以抵消增长放缓带来的估值压力。
- 季报改善是否具有持续性，还是基数、发货节奏或费用确认带来的阶段性变化。

## 技术观察智能体

### 000657.SZ
样本区间：2025-08-13 至 2026-05-15。本模块计算趋势、动量、波动、量能、估值五类指标，共 31 项。

| 指标 | 数值 | 含义 |
| --- | ---: | --- |
| 收盘价 | 56.46 | 最新价格观察基准 |
| 区间收益率 | 232.51% | 衡量样本期方向 |
| 区间振幅 | 338.65% | 衡量高低点波动空间 |
| 最大回撤 | -33.11% | 衡量样本期下行压力 |
| MA5 | 59.66 | 短线均线 |
| MA10 | 59.94 | 短中线均线 |
| MA20 | 57.34 | 月度均线 |
| MA60 | 55.38 | 季度均线 |
| EMA12 | 58.59 | MACD 快线基础 |
| EMA26 | 56.61 | MACD 慢线基础 |
| MACD DIF | 1.98 | 快慢均线差 |
| MACD DEA | 2.02 | DIF 平滑线 |
| MACD 柱 | -0.10 | 动能变化 |
| RSI6 | 23.36 | 短线强弱 |
| RSI12 | 52.39 | 中短线强弱 |
| RSI24 | 57.36 | 中期强弱 |
| KDJ K | 49.92 | 随机指标 K 值 |
| KDJ D | 65.40 | 随机指标 D 值 |
| KDJ J | 18.96 | 敏感摆动值 |
| BOLL 中轨 | 57.34 | 20 日均线 |
| BOLL 上轨 | 65.21 | 压力观察位 |
| BOLL 下轨 | 49.47 | 支撑观察位 |
| BOLL 带宽 | 27.45% | 波动收敛/扩张 |
| BOLL %B | 44.41 | 价格在布林区间的位置 |
| ATR14 | 3.73 | 平均真实波幅 |
| 20日年化波动率 | 79.51% | 近期波动水平 |
| 成交量/5日均量 | 0.84 | 量能确认 |
| 区间价格分位 | 72.75% | 收盘价在样本高低点中的位置 |
| 换手率 | N/A | 交易活跃度 |
| 动态PE | N/A | 估值指标 |
| PB | N/A | 净资产估值 |

综合解读：
- 趋势：收盘 56.46，MA5/MA20/MA60 分别为 59.66/57.34/55.38，结构判断为结构分化。
- 动量：MACD DIF 1.98、DEA 2.02、柱值 -0.10，判断为动能偏弱；RSI6/12/24 为 23.36/52.39/57.36，对应短线偏冷、中期强势。
- 摆动：KDJ K/D/J 为 49.92/65.40/18.96，处于摆动区间内；BOLL %B 为 44.41，价格布林中轨附近。
- 波动：ATR14 为 3.73，20日年化波动率 79.51%，区间最大回撤 -33.11%，说明短期波动压力需要和新闻/公告同步观察。
- 量能：成交量/5日均量为 0.84，换手率 N/A，属于量能平稳。若价格方向与量能背离，信号可信度下降。
- 估值：动态PE N/A，PB N/A，判断为估值数据缺失；估值指标需要和利润增速、现金分红、行业景气度、公司竞争壁垒一起解释。
- 技术面结论：若趋势、MACD、RSI、量能同时改善，说明短线修复更有一致性；若估值仍高而业绩新闻偏弱，则技术反弹更容易受基本面预期压制。

## 风险提示智能体

风险分层：
- 持仓暴露：中钨高新（000657.SZ）市值 56,460.00，组合权重 100.00%，相对成本收益 12.92%。
  推理：单一标的权重较高，新闻、财报或价格波动会直接主导组合净值变化。
- 市场波动：000657.SZ 样本区间收益 232.51%，最大回撤 -33.11%，振幅 338.65%，动态PE N/A，PB N/A。
  推理：价格波动已经具备短期风险暴露特征，需要和新闻事件时间点交叉验证。
- 信息面压力：直接相关新闻 24 条，其中风险类 4 条、正面类 5 条。
  主要风险标题：
  - 中钨高新（000657）5月14日主力资金净卖出5.68亿元_主力研究 - 证券之星
  - 股票行情快报：中钨高新（000657）5月12日主力资金净卖出4.94亿元 - 搜狐网
  - 股票行情快报：中钨高新（000657）5月12日主力资金净卖出4.94亿元_主力研究 - 证券之星
  - 中钨高新（000657）5月8日主力资金净卖出10.42亿元_主力研究 - 证券之星
  可量化风险/支撑线索：净卖出5.68亿元；净利润为12.81亿元、同比较去年同期上涨29.20%；净卖出4.94亿元；净卖出10.42亿元；净利预增超256%；净利大涨264%；净利润同比增长264.44%；净利润同比增长264%。
- 财报公告压力测试：最近财务公告包含 中钨高新:关于参加海南辖区上市公司2025年年报业绩说明会暨投资者网上集体接待日活动的公告；中钨高新:2025年年度报告摘要；中钨高新:2025年度利润分配方案的公告；中钨高新:2025年年度报告；中钨高新:2026年一季度报告。
  推理：年度报告、季度报告、利润分配和业绩说明会公告同时出现时，应重点核对收入增速、净利润增速、现金分红、回购安排和管理层回应。

需要继续追踪的触发器：
- 后续公告是否修正经营目标、分红安排、回购进度或管理层职责。
- 行业需求、产品价格、订单/库存变化是否和财报中的收入/利润变化相互印证。
- 资金流向新闻是否从单日净卖出演变为连续多日同向变化。

## 综合提醒

- 当前示例持仓集中于 A 股单一标的，报告重点应放在业绩增速、分红回购、价格体系、订单/库存、管理层/公告事件和资金面变化。
- 新闻与公告需要交叉验证：新闻负责捕捉市场预期变化，公告负责确认公司正式披露口径，行情负责观察预期是否已经反映到价格和成交量中。
- 后续最值得跟踪的是年度报告和季度报告中的收入、净利润、现金分红、回购进展，以及业绩说明会对经营目标和渠道动销的回应。
- 本系统只做信息整理、现象描述和风险提示，不输出任何买入、卖出或持有建议。

免责声明：本系统仅用于课程演示和市场信息解读，不构成投资建议。

## 最近财报与财务相关公告明细

### 1. 中钨高新:关于参加海南辖区上市公司2025年年报业绩说明会暨投资者网上集体接待日活动的公告

- 股票：中钨高新（000657.SZ）
- 日期：2026-05-08
- 来源：东方财富公告
- 栏目：调研活动
- 链接：https://data.eastmoney.com/notices/detail/000657/AN202605071822030802.html

### 2. 中钨高新:2025年年度报告摘要

- 股票：中钨高新（000657.SZ）
- 日期：2026-04-27
- 来源：东方财富公告
- 栏目：年度报告摘要
- 链接：https://data.eastmoney.com/notices/detail/000657/AN202604261821589507.html

### 3. 中钨高新:2025年度利润分配方案的公告

- 股票：中钨高新（000657.SZ）
- 日期：2026-04-27
- 来源：东方财富公告
- 栏目：分配预案
- 链接：https://data.eastmoney.com/notices/detail/000657/AN202604261821589455.html

### 4. 中钨高新:2025年年度报告

- 股票：中钨高新（000657.SZ）
- 日期：2026-04-27
- 来源：东方财富公告
- 栏目：年度报告全文
- 链接：https://data.eastmoney.com/notices/detail/000657/AN202604261821588866.html

### 5. 中钨高新:2026年一季度报告

- 股票：中钨高新（000657.SZ）
- 日期：2026-04-27
- 来源：东方财富公告
- 栏目：一季度报告全文
- 链接：https://data.eastmoney.com/notices/detail/000657/AN202604261821588879.html

### 6. 中钨高新:关于召开2025年度暨2026年第一季度业绩说明会的公告

- 股票：中钨高新（000657.SZ）
- 日期：2026-04-22
- 来源：东方财富公告
- 栏目：其他
- 链接：https://data.eastmoney.com/notices/detail/000657/AN202604211821379356.html

### 7. 中钨高新:2025年三季度报告

- 股票：中钨高新（000657.SZ）
- 日期：2025-10-27
- 来源：东方财富公告
- 栏目：三季度报告全文
- 链接：https://data.eastmoney.com/notices/detail/000657/AN202510261769370872.html


## 新闻明细（不少于 50 条）

### 1. 中钨高新（000657）5月14日主力资金净卖出5.68亿元_主力研究 - 证券之星

- 来源：证券之星
- 日期：Fri, 15 May 2026 01:18:06 GMT
- 相关标的：000657.SZ
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTE91azk3alNwRlZ3ZlluMVM3QWY5SWJEaWF4Q0luMkUxMmNvQ0hZUHZrZFdZTXB1bDZzYmZHZkQzUWkySldqQVhwbk0wbE5TLWlhem5pcVdhenFKWFdqT1RWalhR?oc=5
- 摘要：中钨高新（000657）5月14日主力资金净卖出5.68亿元_主力研究 证券之星

### 2. 中钨高新：控股子公司拟投资1.825亿元新增高端微型精密刀具年产能1.5亿支 - 东方财富

- 来源：东方财富
- 日期：Fri, 15 May 2026 12:44:22 GMT
- 相关标的：000657.SZ
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYEFVX3lxTE1QaTRYX2N4anFtTnRxb0J1SzBOeWJNVk9CT2JkNzR2T3NwWmtJZy03amhxOHUyUWdhMDVkbF94TmxZNmdiT1hKUjU0RWJCeDFZbVBINzdKRE5tT2R5UWpVVA?oc=5
- 摘要：中钨高新：控股子公司拟投资1.825亿元新增高端微型精密刀具年产能1.5亿支 东方财富

### 3. 中钨高新(000657.SZ)：控股子公司拟实施中粗碳化钨粉智能生产线技术改造项目 - AASTOCKS.com

- 来源：AASTOCKS.com
- 日期：Fri, 15 May 2026 10:15:00 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMinwFBVV95cUxNN0ppWFJDM0pzcDNoeEJvakZoTWpLZDFiTHhMQUdyZExmQjBpVnhnZlR5SXc0MS1IVnVNUTNvV0dXYjRjcGZ4RXE4NE9MZkY5dXpUSktUSGtIclNoRHVJemxWV01QVHI3d0dXWE9BSURhQi1wNkdBY01hN0FhR0ZRUjlVMW02VjRSTGYtNV9ZTVI5aDFrSFVOZnBIdGVod00?oc=5
- 摘要：中钨高新(000657.SZ)：控股子公司拟实施中粗碳化钨粉智能生产线技术改造项目 AASTOCKS.com

### 4. 中钨高新2025年年报净利润为12.81亿元、同比较去年同期上涨29.20%-腾讯新闻 - QQ News

- 来源：QQ News
- 日期：Mon, 27 Apr 2026 07:00:00 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiVkFVX3lxTFBIV0Q5bVRFdXBxOU5lSkZybnU5Q3F2LWVZcTEtY0YwdklRcFNQLVRlUkhqU1E0Yl9rRHVGTUpKYUZHaFE5azM2RVR2c2thZnN3Y080VUtR?oc=5
- 摘要：中钨高新2025年年报净利润为12.81亿元、同比较去年同期上涨29.20%-腾讯新闻 QQ News

### 5. 股票行情快报：中钨高新（000657）5月12日主力资金净卖出4.94亿元 - 搜狐网

- 来源：搜狐网
- 日期：Tue, 12 May 2026 12:51:04 GMT
- 相关标的：000657.SZ
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiVkFVX3lxTE1xdEhselNmRHp3WXRtemE2Znp3SGtBR19kUEFTN3Z5NThFcnprdnlwd1JZeTBLNFFRSkhyblExOHo0OGpIbVJ6M2VKUVJ0MkRPT1ZQQm53?oc=5
- 摘要：股票行情快报：中钨高新（000657）5月12日主力资金净卖出4.94亿元 搜狐网

### 6. 中钨高新早盘快速涨停_新浪新闻 - 新浪网

- 来源：新浪网
- 日期：Thu, 16 Apr 2026 07:00:00 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiY0FVX3lxTE5rWDhXNVRXWGdOQzQxYmNMWFM1Nmw5V2RoYnN6LWpUZlVyWWg3SlVIaHdXdFJDeXNGenpvZ2hYTlliWHEwZy0zRnRfTUVmVi1CUlNaMTdfZkZDbENmUzZPYUx0Zw?oc=5
- 摘要：中钨高新早盘快速涨停_新浪新闻 新浪网

### 7. 股票行情快报：中钨高新（000657）5月12日主力资金净卖出4.94亿元_主力研究 - 证券之星

- 来源：证券之星
- 日期：Tue, 12 May 2026 12:51:04 GMT
- 相关标的：000657.SZ
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTFBON2QteHhTU3pfMUpQdXIxeDJQM3ZPSTd0b2FOa0s1N3I0WklvWEFaRVpmU2FmcDdFNlBwYmg5dTFyQXJNWjd1Z1lSX3hJaTgtQnBfSEp0Z3VMQjhYcjJYVkZ3?oc=5
- 摘要：股票行情快报：中钨高新（000657）5月12日主力资金净卖出4.94亿元_主力研究 证券之星

### 8. 中钨高新：金洲公司拟投资1.83亿元实施印制电路板用高端微型精密刀具技改扩能项目 - 新浪财经

- 来源：新浪财经
- 日期：Fri, 15 May 2026 10:16:54 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiS0FVX3lxTE02RjI2WWRvZE9HUmN4aW1NMjVVd3hKdGVIV0xWV1VITC1YZkpFdndscDNFUy1Ld0FzR3ZrRFVCTWJRTlZxV3NUam1Ucw?oc=5
- 摘要：中钨高新：金洲公司拟投资1.83亿元实施印制电路板用高端微型精密刀具技改扩能项目 新浪财经

### 9. 中钨高新：5月12日融资买入3.66亿元，融资融券余额30.25亿元 - 搜狐网

- 来源：搜狐网
- 日期：Wed, 13 May 2026 03:59:34 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiiAFBVV95cUxQY0hTQU1SenZfRS1FLTctYU5oWjlEeExOQk5TZm1Kc09iTVFhYTZUb0JITDVoNDRrdkUwTExvS3g5RWpHM3dIcVkxa1hKVEM0MFdUb1hfUFo2U2pNTDY1VWs4UktmV0xsWFhxYXZJRDdGOW5qbG1ESl93NGxZcUh4Q3drOXYyN2kw?oc=5
- 摘要：中钨高新：5月12日融资买入3.66亿元，融资融券余额30.25亿元 搜狐网

### 10. 中钨高新：目前公司没有六氟化钨产品公司主要向相关客户提供生产六氟化钨所用到的原材料钨粉 - 东方财富

- 来源：东方财富
- 日期：Fri, 15 May 2026 08:12:50 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiZkFVX3lxTE0yeW9YU1dDZUlQXzBjTV8yM1luVFdHNldJYXRjTlhTRzQ4OWpIUzlqb3FHVnZ6ZDQwTVExQktGTFFTQXo0cjExNjFaM1JoNjN1Vnhqd3VUV0RlM1lHNGRsalNzY3Y2QQ?oc=5
- 摘要：中钨高新：目前公司没有六氟化钨产品公司主要向相关客户提供生产六氟化钨所用到的原材料钨粉 东方财富

### 11. 中钨高新（000657）5月8日主力资金净卖出10.42亿元_主力研究 - 证券之星

- 来源：证券之星
- 日期：Mon, 11 May 2026 01:04:27 GMT
- 相关标的：000657.SZ
- 风险标签：risk
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTE5vUkhXeVNQUXUxUGJ4dGsyN1poSVFrcXBlOS1oR1MwaEY4Y0toNGs4X29OZmJvU0hfbEpSWTQ1Rk5RQ3YwcWZSdjcxbU1VdjV6b1BwVkgwSWZmQUZGQXhHRVFR?oc=5
- 摘要：中钨高新（000657）5月8日主力资金净卖出10.42亿元_主力研究 证券之星

### 12. 中钨高新一季度净利预增超256%_新浪新闻 - 新浪网

- 来源：新浪网
- 日期：Thu, 09 Apr 2026 07:00:00 GMT
- 相关标的：000657.SZ
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiY0FVX3lxTFA0VDJkdDJ1UUJHdkRDeGY5TnBtaFBfeWpWTWQ2RXlac2ZpYktZZEhJcy1xdVpqSmVhLXItalpVa1VUOU5WdC1CdzdoS0JjT1cxX0VPeDI1dUl2bDRNNnZRcERiWQ?oc=5
- 摘要：中钨高新一季度净利预增超256%_新浪新闻 新浪网

### 13. 中钨高新（000657）5月6日主力资金净买入9.16亿元_主力研究 - 证券之星

- 来源：证券之星
- 日期：Thu, 07 May 2026 01:14:03 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTE9XRW1LNmk0S0Q2eGtiRlpxbGVnSzFQLTlocEQyRDhmb0w4ZmotVUJldnNxUkRVTmhWX1FjMlBIU1VobkdsVVF6T1drM1VNU0tTYjRHMGRyWXQyZ1Z5U2xZQmh3?oc=5
- 摘要：中钨高新（000657）5月6日主力资金净买入9.16亿元_主力研究 证券之星

### 14. 中钨高新：拥有PCB微钻、数控刀片、硬面材料、钻齿、难熔金属等多品类行业领先产品_公司新闻 - 证券之星

- 来源：证券之星
- 日期：Thu, 09 Apr 2026 07:00:00 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTE5Bc2t5WEw2eFJNRGlGb0NXRkZRZUVHM2RtaEJDOVp1UWtvUWFvTkFDcjJpWGRyTUpFY2lQYXhhc3FWbGFXaThXcFZLSzRfNElUNHhrUzFPdkpaX3hSR0pJZkJn?oc=5
- 摘要：中钨高新：拥有PCB微钻、数控刀片、硬面材料、钻齿、难熔金属等多品类行业领先产品_公司新闻 证券之星

### 15. "工业牙齿"价格狂飙！中钨高新一季度净利大涨264% - 21财经

- 来源：21财经
- 日期：Sun, 26 Apr 2026 07:00:00 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMijwFBVV95cUxQVDVwM0VrMlk4eUFwYjFjeGZWdUIwMC1XS0NlT3prcmM3c3dsNDM4aTVvVHA5X1ZqcjRYNS1FSV9zdkNDLXhjLTRTRGc5YVp3VUxGVmx2ZkE5R25qLTFjVHR2QzBqSllrQkdvbnZCa2VYV0FKZThCSDltdXNuazE5ZmIzNWpPMWJtMjJwN3FYZw?oc=5
- 摘要："工业牙齿"价格狂飙！中钨高新一季度净利大涨264% 21财经

### 16. 营收4万亿、最高暴涨6136%！有色周期站上风口 后市如何演绎 - 央广财经

- 来源：央广财经
- 日期：Thu, 07 May 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMibkFVX3lxTE5fcF9tLUFMYnRxWlZxUkVnRy1QYXFGWGlDOUxrZVZPR08zZWU2cVB2QmhWVm9aWUltakRiYjdjQU1Gd3ltcEhfZ3p5dmxLY0V4OWExWmxvYnpqQTFYazhZNGFLLU9BTXBxYXNseC1n?oc=5
- 摘要：营收4万亿、最高暴涨6136%！有色周期站上风口 后市如何演绎 央广财经

### 17. 钨企股价连创新高！有股东高位减持，分析师看好这2家钨企 - 证券市场周刊

- 来源：证券市场周刊
- 日期：Sun, 01 Mar 2026 08:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiZkFVX3lxTE5jOTNzYVU0ak5hc1VYbU1iZXpmWjAxLS1ueHdZVExKU1Z3R093d2FuS3lOVlMzbnFOQU9kRnpZOHoxYUhKNDJLbk1vRkNJRWQ5UnR5SEV2Y3Jub0FHeGxiZ1doRHFXQQ?oc=5
- 摘要：钨企股价连创新高！有股东高位减持，分析师看好这2家钨企 证券市场周刊

### 18. 钨价狂飙背后，中钨高新如何靠一座矿山逆天改命？ - 维科号

- 来源：维科号
- 日期：Fri, 15 May 2026 06:39:00 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiVkFVX3lxTE5rblB1TzdpOFlweE9tZGQ4QXgtWlA5WXg5cG5tcDhDTFkzUDctTXktNWVzSmRYei1DMWRTQmZCY1F1Si1sMEtDQ3BWcHlxMWF6dnhBeGp3?oc=5
- 摘要：钨价狂飙背后，中钨高新如何靠一座矿山逆天改命？ 维科号

### 19. 图解中钨高新一季报：第一季度单季净利润同比增长264.44% - 新浪财经

- 来源：新浪财经
- 日期：Sun, 26 Apr 2026 07:00:00 GMT
- 相关标的：000657.SZ
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMigwFBVV95cUxONTB0N3VmbHNRenlUUWl3c01yOW5FMTRzWnJqTmN0SF9PSmpMMjhDbGUyYU1pTkxsN3E4VWF2S3RPM3M0bGpRck5JMGhmYl9lTE5tZVFXVS0tRGVjY1FBVTJlRDhWNm1QM0JKN01BRUdPOVpLWlRhYnpmN0xRTVdaZC1DMA?oc=5
- 摘要：图解中钨高新一季报：第一季度单季净利润同比增长264.44% 新浪财经

### 20. 中钨高新(000657):2025年度业绩承诺实现情况的专项核查报告 - 中财网

- 来源：中财网
- 日期：Mon, 27 Apr 2026 09:26:19 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiVkFVX3lxTE9zQjBzcmV6eGNJRE1qWi1BdTZrY3F3WHY3cVE3RHRtQk8wYVZnN0FPb1BFMXV0RXBxM2VHNjVMRzMtU0o3cmpkRWhVenhYNndmdEQtdWx3?oc=5
- 摘要：中钨高新(000657):2025年度业绩承诺实现情况的专项核查报告 中财网

### 21. 黄金闪耀，锂矿反转！有色金属行业业绩全景盘点 - 证券时报

- 来源：证券时报
- 日期：Tue, 05 May 2026 10:02:20 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiXEFVX3lxTE1GMFQ5UzJJUzJYcGtJZ0dMdVgzZW0wc0tFT1pySXdJSDZjQ0JqZW9icGFuZEwweGt1M0ZqYzhnZ1ZneXZmNk1LWEo1Tno0RlZDQTVWWk1uT2xnbGRz?oc=5
- 摘要：黄金闪耀，锂矿反转！有色金属行业业绩全景盘点 证券时报

### 22. 突发！1600亿化工股重要子公司被美国财政部列入SDN清单 - 富途牛牛

- 来源：富途牛牛
- 日期：Sun, 26 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMioAFBVV95cUxQV3FDYW1JOTAzc3lTYWhRQkFWelptdm5DaXVLbnZQSGhxQ1ZCd3hYdHhwVWh3TTZuR1VPU0lGV3VyRTI3dUJPcHBRTEtlM0pzcUx2Mno2M1dWZm9POGt0bG1BcWFnd0p2cHpGNjRzWjh6VjNsRzJuTkhrem1WN20zQm90TlhXUUhfLU1VUXFUQ21OZnUyWmpadWEtbGNrcFhK?oc=5
- 摘要：突发！1600亿化工股重要子公司被美国财政部列入SDN清单 富途牛牛

### 23. 概念圈︱金属钨：价格创新高，头部玩家即将起飞 - 新浪网

- 来源：新浪网
- 日期：Thu, 05 Jun 2025 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMihwFBVV95cUxQQjNyNW5oSGgzMjJMVWRWQTdvbTZGS0JhZmg2bkJYbXRSN3FaVTNhNFV6TWNMblZlQUhkRHZqM01UTG5XcEJOai1jRGIzeXhCWnN6VnBqdFlVcldxWU15UzQwNml1NEc3Zzl6THhmSHI5b0YySGRqN0gwZU90R19Xc2pqQTgzMGc?oc=5
- 摘要：概念圈︱金属钨：价格创新高，头部玩家即将起飞 新浪网

### 24. 【马斯克太空光伏十倍标的龙头：先上60元长线百元｜金刚石线｜业绩爆增】 - 财富号

- 来源：财富号
- 日期：Sat, 09 May 2026 03:17:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMia0FVX3lxTE42RlFYS25GbDVOYTlNSnZnWmxjS096TXU1RUdqYUhzaDllZ083R0RaZFBVQzlqQlRUV1Bpbk1TTU1LYlVEQWJPZkgxdVlPRGxzZjlUTHQtY1dCLWc2NjRWZ2lodU5LV1BYMTZv?oc=5
- 摘要：【马斯克太空光伏十倍标的龙头：先上60元长线百元｜金刚石线｜业绩爆增】 财富号

### 25. 钨价狂飙超6倍！A股钨板块全线大涨，章源钨业2025年净利大增近七成 - 时代在线

- 来源：时代在线
- 日期：Tue, 21 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiS0FVX3lxTE4wOVBWT0FQRWdlN25ETzFWNkF3LWlqMDdrV0htNHlNX0NRUFluQk5rVUp3S1BsQmpEZlFtS1Y1TkdlRGl3MFdtbDJ3QQ?oc=5
- 摘要：钨价狂飙超6倍！A股钨板块全线大涨，章源钨业2025年净利大增近七成 时代在线

### 26. PCB设备2025年报&2026年一季报总结：业绩兑现元年，关注技术通胀带来的非线性增长_行业研究_研报 - 证券之星

- 来源：证券之星
- 日期：Wed, 13 May 2026 02:43:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYkFVX3lxTE13WjFfM3liTnBpY0c4cFhrbEdpWnVlcjJIaWVhcUphbHZVVi03Rmt2MGdHb0wzVko0SzNXbFA2cHlQNVZmbFBvR0wtTzVVZnBtUnpJOWJhN0xkOWQyVGgwRHVB?oc=5
- 摘要：PCB设备2025年报&2026年一季报总结：业绩兑现元年，关注技术通胀带来的非线性增长_行业研究_研报 证券之星

### 27. 厦门钨业利润大增不及预期_新浪新闻 - 新浪网

- 来源：新浪网
- 日期：Thu, 23 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiY0FVX3lxTE1ndGhlWXNYVGtMRlhzQzRrTDV1TWxZSmU3QmVUZkFFWTZoS1ZLZzlfRlhSaUtnOEFXSXFXYkxYeXZzdWdVeUE0VTRESHJJU1liRUdmejVsc3loNjI2OUY1WDJjRQ?oc=5
- 摘要：厦门钨业利润大增不及预期_新浪新闻 新浪网

### 28. 光模块都新高了，PCB会不会跟上？ - 新浪网

- 来源：新浪网
- 日期：Thu, 16 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMidkFVX3lxTE5fOTNOTWJBRnhDNlhpYm1LZ3pBeFRhbkdDS2Q5RDFzeUxnbFRnZXNyREUtakRaTk13aGZleHJIMlBhUXAzREVONlJ1Y0J1VGxBaHRHOVV0NGpKZ0NfRndlc3VaQlVXZFV5LXA5eFpUZjA0Y2N4ZXc?oc=5
- 摘要：光模块都新高了，PCB会不会跟上？ 新浪网

### 29. 晚间公告｜4月26日这些公告有看头-腾讯新闻 - QQ News

- 来源：QQ News
- 日期：Sun, 26 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiVkFVX3lxTE9CNUtlZkgyX3Z0QmE1Y2ZycEk3YkZHMVp0cDNfODliVVBpZXZncjJ3YkZFU1FvdVBKQWhJN2hWdnB1SGluZzdIZWdCY0pjeHRBdF9TcUxR?oc=5
- 摘要：晚间公告｜4月26日这些公告有看头-腾讯新闻 QQ News

### 30. A股收评：沪指失守4200点，近4400股下挫，猪肉、白酒概念逆市走强 - 新浪网

- 来源：新浪网
- 日期：Thu, 14 May 2026 07:29:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMigAFBVV95cUxNODFNaWFJYmxTTzJqMTVWTUFnS0lac3psby16TXJaQkJaTkpNQmt1S0toZXJTQjIwU01abHpvQmtnaFA5dk4wZ1dqd3JDdnphZmdCbmlka3M2QlJDWktnMGpCY25wNjFOQWxoUGNHWXRPZG1hWnRHbW5GWGdFeDNfNw?oc=5
- 摘要：A股收评：沪指失守4200点，近4400股下挫，猪肉、白酒概念逆市走强 新浪网

### 31. 9.56亿资金抢筹中钨高新 机构狂买大普微丨龙虎榜 - 东方财富

- 来源：东方财富
- 日期：Thu, 16 Apr 2026 07:00:00 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiZkFVX3lxTFB4TERUV0tpakxOcWZTY29jdjJWRFYwcWtRXzhfQXJJaDlYQXVjU3JqaEVCLTh0T2hxRTNHckpIZVdqVzBRWl9CM2Q3MkJZTzJmRjRPZ0o5bjI1SUpheUxyZGdhSHdrQQ?oc=5
- 摘要：9.56亿资金抢筹中钨高新 机构狂买大普微丨龙虎榜 东方财富

### 32. 15:46:23【中钨高新：第一季度净利润同比增长264% 主要系产品量价齐升所致】 - 财联社

- 来源：财联社
- 日期：Sun, 26 Apr 2026 07:48:39 GMT
- 相关标的：000657.SZ
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiSEFVX3lxTFBIaE4zaTZWSUZJWTlZMlpwS3ZaNVd0cG9hUExGZzdqWEg4c3VwWjBvRC1YOVpSMlVSVGtmMHdOM19qVVJ1akVVcQ?oc=5
- 摘要：15:46:23【中钨高新：第一季度净利润同比增长264% 主要系产品量价齐升所致】 财联社

### 33. 美、以军事打击伊朗，A股两支“战争金属”股还会继续涨？ - eeo.com.cn

- 来源：eeo.com.cn
- 日期：Sun, 01 Mar 2026 08:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiV0FVX3lxTFBUbEJkSnBvRmpKeUxzNmJZWC1uY3lyOU5CckVmVk5hbWxkZGJSRWFCQjZQaVI3YjlWVmtieU5kc3E2dXdSMEFIODNZcGFXQWE3NnRrVzBjQQ?oc=5
- 摘要：美、以军事打击伊朗，A股两支“战争金属”股还会继续涨？ eeo.com.cn

### 34. 中东战火致“战争金属”价格飙升 相关概念股集体飘红 - 财新

- 来源：财新
- 日期：Wed, 04 Mar 2026 08:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiXEFVX3lxTE9RVTFYeng4eDhyTzJJWldmUDBYdzMxMlY2MDVHT0c4M2NkQVlJZnBHTUVmR2NOdVo5eXN0c1p5d3hfQk1uOWt2b1czVkpOcGxOalpHaGhfcUtzT2RJ?oc=5
- 摘要：中东战火致“战争金属”价格飙升 相关概念股集体飘红 财新

### 35. 钨粉价格飙升超400%，华锐精密三个月发4次涨价函，去年至今股价暴涨266% - 时代在线

- 来源：时代在线
- 日期：Wed, 25 Feb 2026 08:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiUEFVX3lxTFAtRXhSN0gxOUpNZFIxRTJlSWFlZmJVZWRyT1VzNTBPSnVhS29sZGRtVWFUS283dlZoTzc1ZXZ1NVFBTENSQnJseDIxRTJWd3pf?oc=5
- 摘要：钨粉价格飙升超400%，华锐精密三个月发4次涨价函，去年至今股价暴涨266% 时代在线

### 36. A股收评：高开高走！深证成指创逾4年新高，创业板指创近11年新高，锂矿、有色、算力股领涨 - 中金在线

- 来源：中金在线
- 日期：Thu, 16 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMib0FVX3lxTE15Y1dIUGpZMzdSVFdLdUdOMVQxUHl0Z0hmdHB0aDdyei1uQnhBRFVISXFrS0hYMjVfZjJiR2RSaldMQTJQUmRNcU55SEJNdVdMcFp4WGF3dkEzMnN3VjZyUHlGQjFDNDI1T1dtb0JUUQ?oc=5
- 摘要：A股收评：高开高走！深证成指创逾4年新高，创业板指创近11年新高，锂矿、有色、算力股领涨 中金在线

### 37. 中钨高新(000657.SZ)：金洲公司拟投1.83亿元新增高端微型精密刀具产能1.5亿支/年 - 凤凰网

- 来源：凤凰网
- 日期：Fri, 15 May 2026 20:07:09 GMT
- 相关标的：000657.SZ
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiSEFVX3lxTE5wZS1QQzJZM1hKTnltaUVPa2x2TGVaYThmaWZPWjFoa2pCV0gwX3F0LWtHLXhkY3BYZzAxTVFHeTFsU290Ny15cg?oc=5
- 摘要：中钨高新(000657.SZ)：金洲公司拟投1.83亿元新增高端微型精密刀具产能1.5亿支/年 凤凰网

### 38. 个股一季度业绩增长_新浪新闻 - 新浪网

- 来源：新浪网
- 日期：Sun, 26 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiY0FVX3lxTFB3RXh0bkpCSW9yU3Y5OFJZWVF4TENpSHRsZFZYYmt1UjdwcURzUnBoVk50MFFwdXk4M2FiZXotYTBQelJNRmwtb1BmNEo4YllUT1lwb2tCR28wZ0MzTXY2WTJvVQ?oc=5
- 摘要：个股一季度业绩增长_新浪新闻 新浪网

### 39. 商业航天概念依旧活跃 - 紫牛新闻

- 来源：紫牛新闻
- 日期：Fri, 10 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiaEFVX3lxTE5jVjA1Y3ppd1h4eUdTcE80UHdUdWRidTBVOE1uTF9nMDBFUU5IQV83N0hBVmxjMkd4ZTRhZWtOMG5tazhvMzlPUURTblB2emFtS016SFpRMWZuTmg5eHBHOXpCa0ZwQ21W?oc=5
- 摘要：商业航天概念依旧活跃 紫牛新闻

### 40. 中钨高新(000657.SZ)：目前金洲公司PCB钻针订单饱满，市场需求旺盛 - Moomoo

- 来源：Moomoo
- 日期：Wed, 13 May 2026 13:25:03 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiU0FVX3lxTE1IUXNPQVR3M1hKcUdtMHhmYWFQbmU2WG5Ra3o2dVE0ZUlBNFV2cUs5eElsdGd1RkxBMEF0cFNpd0ZVUkhKV1hGSnZqT0VmYUdibnF3?oc=5
- 摘要：中钨高新(000657.SZ)：目前金洲公司PCB钻针订单饱满，市场需求旺盛 Moomoo

### 41. 中钨高新：金洲公司拟投资1.83 亿元实施印制电路板用高端微型精密刀具技改扩能项目 - MSN

- 来源：MSN
- 日期：Sat, 16 May 2026 23:59:47 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMihwRBVV95cUxQajZvWHllWFRxLWtxVDF0VnlwcmZNa3NYanRMTWhfMm90WVJBNG5sVkp4QlY5X1B3eUtWTUpQNmE4WXRfVkNNdUxrTzZxdzdreGxwZHpFOHdLTVVhSUxfMnk0SmRfNGN5c2g5UnByODEzTVZ1RktTLUZVemx4bm1mZE03YmVuYjBuUWFQb3l0UE9FTG4tcWttdWxwVVgxVHQ3UG04bGN1WGM4THlicVhRSEtNSi1FY1JLODFvb0dYUDRFbXVJNi1fSFFubzJ0YlJOck1nTDV5b0RXZ003VGpiTVViNXRMa3NycTF5ZTZQV1JSVkZiQkpxeTVIY2VyLUxkeDNXZmhVNGxnS3d3dXF1MnBOdS16eWRnTlZKdzY0dUJLOFh4N2VqVE16UDl0a0xSemdOQVptbVFwZjBmXzhwOFRBYTUyX0dMWGxKVVFFMmUtU3pqTjVoZ21PQTU1akFoMkttRVp4RUZBTGkxS0hXU05LQmtRQlBOcUgtbHpFeVlyeTRMNHN5TGk2OTFoWHhGMy1pYnRYRnlqbDV1MWdNTVhsckltb1pwZFFRNlR3UzZQcDJfY0JwbGFiSXB3QU9yQ2JzeW9fQVBhQUtzYXMzSDU5U3I5TUJvT2JOWFdER05qQUZxX1ZCbEhpT1ZUUnBhX2lfcHVVcFhtWEFNOTl3S3ozcE9yUEE?oc=5
- 摘要：中钨高新：金洲公司拟投资1.83 亿元实施印制电路板用高端微型精密刀具技改扩能项目 MSN

### 42. 中钨高新(000657.SZ)：目前金洲公司PCB钻针订单饱满， 市场需求旺盛 - MSN

- 来源：MSN
- 日期：Sat, 16 May 2026 23:07:38 GMT
- 相关标的：000657.SZ
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMi9wJBVV95cUxPV2UzMG1mSG5FWkNTbFhfVDBwNm9FZ24tQkg3M2JGelJORkxjcng2V1BCM2tGVkgtSi1WakdEV1IzRlBHRF9ubUZJZXBwU19XT0lxYjZGd0Q3Qmxid091Y216bFQ1X09TQ1Bpc2NwQVFxWmtBcDAwa09pWExnYUdiLUp3RTdGRE8zTWxxMkRGbktQQUdzaUdyODZJZ1NnYUU2aDNlLVRTMENPV2czWS0tekN4TmhkcWU5MldYVlZOSnhuZDRQSmdtNWtmeUtqVW9OdnByUlhTYTZ2SXlDTjlLSkZEaVQ4R1VFdjZTNDY0dHptMkRTaF9FM2dLVk5aUHlBdF96aVp1VFZfVVdJdHRjeDViUzlmS0MyeFM2cE9GMy1NN2VBdHpFUXZScVBkd1dYbUV0Vm5leXRzcmV3ZG1sZmpTamt2M19CX3ZaS2U5UHZuQWxJZW4xNFpueURhWGxVTmVHMDN3UEhuMU9tUHZCd2owNk1MRGs?oc=5
- 摘要：中钨高新(000657.SZ)：目前金洲公司PCB钻针订单饱满， 市场需求旺盛 MSN

### 43. A股早盘高开高走，单边上行大幅上涨：AI应用、半导体全线走强 - thepaper.cn

- 来源：thepaper.cn
- 日期：Wed, 08 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiXkFVX3lxTE9nbk1MVjMwbDdfTV9VRkhwNEtkRm4wQWkwLU1fSHVJZ1JFWEo1YUFkNFRfbWp6MEx1em5jMmRXV0ZZSVB1Tkctbl9USXRhaEEyMEx0OHgtbzlzYVhLd2c?oc=5
- 摘要：A股早盘高开高走，单边上行大幅上涨：AI应用、半导体全线走强 thepaper.cn

### 44. 主力资金丨消费电子热门股获青睐 主力逆市抢筹股出炉 - 证券时报

- 来源：证券时报
- 日期：Thu, 14 May 2026 11:10:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiV0FVX3lxTE82S3NGUEJEOHBiSFVFVkEwTy13eDhvV2lHRjdkZjRhcTE3ZXg3OTVNd29lWkFybExYeVdvT0liZDMzNUdtY1p0TEpXRUJPZndwdnlGVmY4WQ?oc=5
- 摘要：主力资金丨消费电子热门股获青睐 主力逆市抢筹股出炉 证券时报

### 45. 中国有色资产定价逻辑重构 - 21财经

- 来源：21财经
- 日期：Fri, 15 May 2026 23:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMihgFBVV95cUxNTm5TTzNLbXZFUVhTWVFjbFF5cC1zN0FYT1hCNHQ4NzVHaVBNX3FiQWhmb3ZwSHBYdmFkc0Y0VkVPYXNETjJ3dVlybktRdHkxY0FnYlpJMGlfQUo0a2ZTNmhLN2xuM3o1aWswUnRLbmhpVnhQOVZrdUhQRzg1MG15a2hoWV9fQQ?oc=5
- 摘要：中国有色资产定价逻辑重构 21财经

### 46. 中际旭创总市值首破万亿后，A股为什么突然跳水了？ - 新浪新闻_手机新浪网

- 来源：新浪新闻_手机新浪网
- 日期：Thu, 23 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMidEFVX3lxTFBqZmdPTWpSUzJCN1R6T3c0SzBvYjlKaTdWa3laYU1mWEppYzV5alpXOFhDcGRqSmQxU3I3dW1UNk5SVl83akphbk1lenJweWdzVG5qY3BUMTlLb19yV0p5NTNQVTVYRGdjWDY3RDA5ckp1aUF5?oc=5
- 摘要：中际旭创总市值首破万亿后，A股为什么突然跳水了？ 新浪新闻_手机新浪网

### 47. 午评：创业板指探底回升涨0.57% 机器人概念股大涨- 中国金融信息网 - 中国金融信息网

- 来源：中国金融信息网
- 日期：Fri, 15 May 2026 03:53:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiZ0FVX3lxTE1QVnJaU09PdUxzVW1hZW1tRTBPMVpIT2NhMUxrVjFheGVmWS1VYng4WU14aU9vdjBKY2JLZkp0b1NpZ05RS1RMcVlpZ2VMbnJlMGQxR3E1eVFHT1JGbXZiNEJYc25nQTg?oc=5
- 摘要：午评：创业板指探底回升涨0.57% 机器人概念股大涨- 中国金融信息网 中国金融信息网

### 48. A股马年“开门红”！新一轮攻势启动？ - 国际金融报

- 来源：国际金融报
- 日期：Tue, 24 Feb 2026 08:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiX0FVX3lxTE01X1k3RVRnOVlvZ01ZZ3huQU9PUWVoNHZLOHJSMGQ0QXNqYWlIV01ZblRXWTc0RUxTNnVjbkZWYmlDVHhyRHdiYnkwUjY2UDNRWWNtTllod1plN3Y0RkRz?oc=5
- 摘要：A股马年“开门红”！新一轮攻势启动？ 国际金融报

### 49. 港股异动丨铜业股走高 中国有色矿业涨5% 铜价逼近历史新高 - AASTOCKS.com

- 来源：AASTOCKS.com
- 日期：Tue, 12 May 2026 01:53:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMimAFBVV95cUxPTHdZaWZQdEZBcFBtWXFpZVczSk5nWUFxTjJiQnhtOFFHTXdteDRaYTdJS1FlbDlIT0lWSGcyTW9PalM0ZUFmU0ROQjZnUXZnM1VBX1BBUmNlMzMxRXVQN04tQ1RWeHF5VVVjemhFOVFwYk1vbmNES2tCb3dDSElyYlA0ZTRDVmNXNDhBMnFBeWtOdHlHRUVXbA?oc=5
- 摘要：港股异动丨铜业股走高 中国有色矿业涨5% 铜价逼近历史新高 AASTOCKS.com

### 50. 险资一季度调仓路线图：增配消费，加筑银行等高股息底仓 - Jiemian.com

- 来源：Jiemian.com
- 日期：Fri, 15 May 2026 07:19:42 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：positive
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiWEFVX3lxTE1XcVd1ZHJBYmVIbXZHOFpuSnI2RWFlSUJvNDAxblctS0k1NDJOa0dzdUdEYTY1SFRkVHBsdzI2XzJtY05JWmk4dXZQemV6S0dOeGlLbEd4THM?oc=5
- 摘要：险资一季度调仓路线图：增配消费，加筑银行等高股息底仓 Jiemian.com

### 51. 沪指跌3.6%险守3800点，全市场超5100股下跌，黄金股集体暴跌，恒指跌超3%，科网股普跌 - 华尔街见闻

- 来源：华尔街见闻
- 日期：Mon, 23 Mar 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiU0FVX3lxTE5RSFdXZExhZWxmR2dMUW9DYlYtWmRqb3JuOHBuWmlCaGxzc21zTjNvYjkwRmxST1NfTlJIcV9aUzRiMWRYcDRFWnhNZzhUNnoxMW9z?oc=5
- 摘要：沪指跌3.6%险守3800点，全市场超5100股下跌，黄金股集体暴跌，恒指跌超3%，科网股普跌 华尔街见闻

### 52. 十基金解读A股百点长阳：市场将进入重定价阶段，寻求中长期线索是更优选择 - thepaper.cn

- 来源：thepaper.cn
- 日期：Thu, 09 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiXkFVX3lxTE5ybXJQdEMxRVBRbnA5UkQta21ZSjRkanBjSWpTOGxTenN4bGd0Wjd5VFVUV3dNVC1tcVVlRWtHNFlnX0F2WlFwbllFd0VFc2RHQ0RoYjVWaFMweW4ySkE?oc=5
- 摘要：十基金解读A股百点长阳：市场将进入重定价阶段，寻求中长期线索是更优选择 thepaper.cn

### 53. 4月最牛金股大涨93%！5月名单曝光：这只消费股成“人气王” - 21财经

- 来源：21财经
- 日期：Tue, 05 May 2026 14:07:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMijwFBVV95cUxNQ2J3UVcwM0w1SV9TWTFWYW5yckVjZy1TN1JydzNlcVJYRC1Pblk5ZmhtVWFYc3RDaVlHSE9raEFuaWEzRFVOQlZVaXh2U0x4Tl9jS09EbVc0NnlSYlVCa05aX0lPcGUwY3pGQ1I5TlE2UnRNcW9mSzE5XzNwXzhXY29LMXZma0RzUHFuR205OA?oc=5
- 摘要：4月最牛金股大涨93%！5月名单曝光：这只消费股成“人气王” 21财经

### 54. A股三大股指集体收跌，煤炭、油气、电力逆势走强 - 新浪新闻_手机新浪网

- 来源：新浪新闻_手机新浪网
- 日期：Thu, 23 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMi2wFBVV95cUxOUmd0S2o2RU5ZYkRDVkU2THlxN1BwaUhDRDBmYnBPV0lab3RxUHl1NmpySFEwUFcxR19KeFYtLTRjYVgzM2FENTd4aEhoMWFzRFhya2RycWlNVzdkZFFrb0Y1cW40SDlCb0Q2T3NzZGkzNy1IX0VXNUNvVDNKRG96MU5RRnc0MUJlWk56R1BTWUR6eHBuRU1pMlJjeFNheV82aktkajY5YkJSNHpHZTV3T3FxaDdtd21wX01BSDlKN0psU196UXJfckw4UVVVdmNabW1QbXNMRU41VFU?oc=5
- 摘要：A股三大股指集体收跌，煤炭、油气、电力逆势走强 新浪新闻_手机新浪网

### 55. 紫金陈：建仓消费股！“写作和炒股收益差不多对半开” - 证券时报

- 来源：证券时报
- 日期：Sat, 16 May 2026 08:14:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiV0FVX3lxTE11akRNRkF3YWIzaHp0X1NpTmUxWGZwVlNva2dmZDBiQmg4ZmZHNVgyLXFaSUhEejVwTTJsenhRWm1kUjlXQTdRUEtTY0tMM3FqTk43WnlUTQ?oc=5
- 摘要：紫金陈：建仓消费股！“写作和炒股收益差不多对半开” 证券时报

### 56. 港股异动丨铜业股走高中国有色矿业涨5% 铜价逼近历史新高财经新闻Financial News - AASTOCKS.com

- 来源：AASTOCKS.com
- 日期：Tue, 12 May 2026 01:53:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMikwFBVV95cUxPODJVVnp1RHdOMlhqcnlWTUlDUTA2WWQ4VGFKX1lrazM3VG55ZklRZHhqWVdkblptSlR3ek1SQ3gyRmdzZHlCaVI3dktXY3hjM2QzR2RnN01ubEN1UjRhQ3FmRWdjS09YVzJBWDBadlNYUWVBTjh1WGtrVEN3X2J3VUdJM3cwd3NkZG16ZHgwbm1uLVE?oc=5
- 摘要：港股异动丨铜业股走高中国有色矿业涨5% 铜价逼近历史新高财经新闻Financial News AASTOCKS.com

### 57. 尾盘直线拉升！301217，20%涨停！4股获巨资抢筹 - 新浪财经

- 来源：新浪财经
- 日期：Wed, 29 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMikgJBVV95cUxPckEtV0ZBZGZHaTljclc0N3VFekhocFJKNElaRkVvdVgwZjlpNk5DWXJJYU9UUTFqVHVzMFBBZEVlZ0RYRGpGYUtiYjkzbkdQcmJQZnFBTmF4SzRPTkZwb1lKMUJOQTd0eFpySE9yb2lYSVZUTlc3SDc4YXFkQVQtZ2tFdXRiR0JIbkdWN2hxVWl2Z3ZSWTUxa01UYlVlYWNBN1JHejZyMHRicmQ2Y3QwQ0owclJrQ2piM0FEZ1B5aDROczVsWFZQaHhTMWY2akFIQnN6UW5uOTFFYTVIZlZiN0JRYm85Y1J1UFM1Q1RYREEtenVkS0pwVUJid3FodVoxQVUyRW1WTkV1UFRBQUJUSXp3?oc=5
- 摘要：尾盘直线拉升！301217，20%涨停！4股获巨资抢筹 新浪财经

### 58. A股窄幅震荡，三大股指涨跌互现：半导体、算力硬件产业链爆发 - thepaper.cn

- 来源：thepaper.cn
- 日期：Mon, 27 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiXkFVX3lxTE5acGstMTlpbzBsLWpzcERZYlEyQ3ZYa3JrUExkUnp3b2FLcnpabmU1RkNldE9nRnJZTkNYNXBSVGNNZFNTSzlSN3J6aDBUendqZ18zY2RQVnZuTkNWOXc?oc=5
- 摘要：A股窄幅震荡，三大股指涨跌互现：半导体、算力硬件产业链爆发 thepaper.cn

### 59. A股三大股指跌超3.4%，沪指险守3800点 - thepaper.cn

- 来源：thepaper.cn
- 日期：Mon, 23 Mar 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYEFVX3lxTE16R0xqckFFRHZHRWVUZzJkMG51QlJJNWp1blBkWUx3elozUTNoR2stTEVYXzlORmFOOHF0dXFjTnpfX25xak8zN1Bnc28xcWhkeGlqcjNZZWZXNkJyTDhHSw?oc=5
- 摘要：A股三大股指跌超3.4%，沪指险守3800点 thepaper.cn

### 60. 沪指涨1.46%，创业板指涨1.96%：医药生物板块大幅上涨，超4400股飘红 - thepaper.cn

- 来源：thepaper.cn
- 日期：Wed, 01 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiYEFVX3lxTE5LMHBkMkRWaTFLb1JWei1TYmJsMV9JUHNpYm5kVGpxaDkxNDFrNWVocHVSSmNIQmZHNWNUeHB3QnY3UjNCZ0J0RElnS2Q3c2dmRklvaTBrQ0N1eWZGc0ZpZQ?oc=5
- 摘要：沪指涨1.46%，创业板指涨1.96%：医药生物板块大幅上涨，超4400股飘红 thepaper.cn

### 61. A股午盘三大指数上涨_新浪新闻 - 新浪网

- 来源：新浪网
- 日期：Wed, 22 Apr 2026 07:00:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMiY0FVX3lxTE5maVdZSjFwU0x1bjQ2alZ2TlV1Nkh1UjRMcmREQ0ZxMExJMFRvR0NTX2tUeWVVekhpcjdmeTgzbm1PRkktUGttRUVnWHZBOGt0S3NqOHE3cV8zREp2dmRuNzdwQQ?oc=5
- 摘要：A股午盘三大指数上涨_新浪新闻 新浪网

### 62. 港股三大指数集体收涨，红利指数震荡上行 - 财富号

- 来源：财富号
- 日期：Fri, 24 Apr 2026 10:36:00 GMT
- 相关标的：未直接匹配持仓标的
- 风险标签：neutral
- 抓取方式：google_news_zh_rss
- 链接：https://news.google.com/rss/articles/CBMia0FVX3lxTE9CQlZTaVFGZnQ1SHY1YXBmV0NfZm1oYS1JcTVTNFEwZ1RFWGMwYjNpdWlPVml2bUxUWUVtbTFOajJOVGJCc1hwLVNVOGlQT0RYeXdWNHZkZWVrNDIyYnlUcmF2RWlJU0FyU1dV?oc=5
- 摘要：港股三大指数集体收涨，红利指数震荡上行 财富号

免责声明：本系统仅用于课程演示和市场信息解读，不构成投资建议。